import { useEffect, useRef, useState } from "react";

export type PageName = "home" | "experiments" | "projects" | "tools" | "modules" | "profile";

export type Route =
  | { page: PageName }
  | { page: "experiment"; id: number; sub: string | null }
  | { page: "module"; id: string };

/**
 * Hash routes:
 *   #/                         home
 *   #/experiments              experiment list
 *   #/projects                 projects
 *   #/modules                  learning modules
 *   #/modules/abc123           one learning module and its topics
 *   #/tools                    learning tools
 *   #/profile                  profile
 *   #/experiment/1             main experiment tab
 *   #/experiment/1/EXP-01.A.1  sub-experiment tab
 */
export function parseRoute(hash: string): Route {
  const experiment = /^#\/experiment\/(\d+)(?:\/([^/?#]+))?/.exec(hash);
  if (experiment) {
    let sub: string | null = null;
    if (experiment[2]) {
      try {
        sub = decodeURIComponent(experiment[2]);
      } catch {
        sub = experiment[2];
      }
    }
    return { page: "experiment", id: Number(experiment[1]), sub };
  }

  const learning = /^#\/modules\/([^/?#]+)/.exec(hash);
  if (learning) {
    let id = learning[1];
    try {
      id = decodeURIComponent(id);
    } catch {
      // Keep the raw id.
    }
    return { page: "module", id };
  }

  const page = /^#\/(experiments|projects|tools|modules|profile)(?:[/?#]|$)/.exec(hash);
  if (page) return { page: page[1] as PageName };

  return { page: "home" };
}

export const pageHref = (page: PageName): string => (page === "home" ? "#/" : `#/${page}`);

export const moduleHref = (id: string): string => `#/modules/${encodeURIComponent(id)}`;

export function experimentHref(id: number, sub?: string | null): string {
  return sub ? `#/experiment/${id}/${encodeURIComponent(sub)}` : `#/experiment/${id}`;
}

export function useRoute(): Route {
  const [hash, setHash] = useState(() => window.location.hash);
  const last = useRef<Route>(parseRoute(window.location.hash));

  useEffect(() => {
    const onChange = () => {
      const nextHash = window.location.hash;
      const next = parseRoute(nextHash);
      const previous = last.current;

      // Switching tabs inside one experiment keeps the scroll position.
      const sameExperiment =
        previous.page === "experiment" && next.page === "experiment" && previous.id === next.id;
      if (!sameExperiment) window.scrollTo({ top: 0, behavior: "auto" });

      last.current = next;
      setHash(nextHash);
    };
    window.addEventListener("hashchange", onChange);
    return () => window.removeEventListener("hashchange", onChange);
  }, []);

  return parseRoute(hash);
}
