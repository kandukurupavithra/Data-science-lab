import { cleanFileName, uniqueFileName } from "./files";
import { createPersistedStore } from "./persisted";

export interface Topic {
  id: string;
  title: string;
  notes: string;
  done: boolean;
  createdAt: number;
}

/** A code or text file kept inside a module. */
export interface ModuleFile {
  id: string;
  name: string;
  content: string;
  createdAt: number;
  updatedAt: number;
}

export interface LearningModule {
  id: string;
  title: string;
  description: string;
  topics: Topic[];
  files: ModuleFile[];
  createdAt: number;
}

const isObject = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null;

const plural = (count: number, word: string) => `${count} ${word}${count === 1 ? "" : "s"}`;

function toTopic(value: unknown): Topic | null {
  if (!isObject(value) || typeof value.id !== "string" || typeof value.title !== "string") {
    return null;
  }
  return {
    id: value.id,
    title: value.title,
    notes: typeof value.notes === "string" ? value.notes : "",
    done: value.done === true,
    createdAt: typeof value.createdAt === "number" ? value.createdAt : 0,
  };
}

function toFile(value: unknown): ModuleFile | null {
  if (!isObject(value) || typeof value.id !== "string" || typeof value.name !== "string") {
    return null;
  }
  const createdAt = typeof value.createdAt === "number" ? value.createdAt : 0;
  return {
    id: value.id,
    name: value.name,
    content: typeof value.content === "string" ? value.content : "",
    createdAt,
    updatedAt: typeof value.updatedAt === "number" ? value.updatedAt : createdAt,
  };
}

function toModule(value: unknown): LearningModule | null {
  if (!isObject(value) || typeof value.id !== "string" || typeof value.title !== "string") {
    return null;
  }
  return {
    id: value.id,
    title: value.title,
    description: typeof value.description === "string" ? value.description : "",
    topics: Array.isArray(value.topics)
      ? value.topics.map(toTopic).filter((topic): topic is Topic => topic !== null)
      : [],
    // Modules saved before files existed have none.
    files: Array.isArray(value.files)
      ? value.files.map(toFile).filter((file): file is ModuleFile => file !== null)
      : [],
    createdAt: typeof value.createdAt === "number" ? value.createdAt : 0,
  };
}

const store = createPersistedStore<LearningModule[]>(
  "ds-lab-workbench:learning",
  [],
  (value) =>
    Array.isArray(value)
      ? value.map(toModule).filter((item): item is LearningModule => item !== null)
      : [],
);

export const useLearningModules = store.useValue;

const newId = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

/** A short description of what a module holds, such as "3 topics and 2 files". Empty when it is empty. */
export function describeModuleContents(item: LearningModule): string {
  const parts: string[] = [];
  if (item.topics.length > 0) parts.push(plural(item.topics.length, "topic"));
  if (item.files.length > 0) parts.push(plural(item.files.length, "file"));
  return parts.join(" and ");
}

/* -------------------------------- modules -------------------------------- */

/** Creates a module and returns its id so the caller can open it. */
export function addModule(title: string, description: string): string {
  const id = newId();
  const created: LearningModule = {
    id,
    title,
    description,
    topics: [],
    files: [],
    createdAt: Date.now(),
  };
  store.set((modules) => [...modules, created]);
  return id;
}

export function updateModule(
  id: string,
  changes: Partial<Pick<LearningModule, "title" | "description">>,
) {
  store.set((modules) =>
    modules.map((item) => (item.id === id ? { ...item, ...changes } : item)),
  );
}

export function removeModule(id: string) {
  store.set((modules) => modules.filter((item) => item.id !== id));
}

/* -------------------------------- topics --------------------------------- */

export function addTopic(moduleId: string, title: string, notes: string) {
  const topic: Topic = { id: newId(), title, notes, done: false, createdAt: Date.now() };
  store.set((modules) =>
    modules.map((item) =>
      item.id === moduleId ? { ...item, topics: [...item.topics, topic] } : item,
    ),
  );
}

export function updateTopic(
  moduleId: string,
  topicId: string,
  changes: Partial<Pick<Topic, "title" | "notes" | "done">>,
) {
  store.set((modules) =>
    modules.map((item) =>
      item.id === moduleId
        ? {
            ...item,
            topics: item.topics.map((topic) =>
              topic.id === topicId ? { ...topic, ...changes } : topic,
            ),
          }
        : item,
    ),
  );
}

export function removeTopic(moduleId: string, topicId: string) {
  store.set((modules) =>
    modules.map((item) =>
      item.id === moduleId
        ? { ...item, topics: item.topics.filter((topic) => topic.id !== topicId) }
        : item,
    ),
  );
}

/* --------------------------------- files --------------------------------- */

/** Adds a file to a module. A name that is already taken gets " (2)" added. Returns the file's id. */
export function addFile(moduleId: string, name: string, content: string): string {
  const id = newId();
  const now = Date.now();

  store.set((modules) =>
    modules.map((item) => {
      if (item.id !== moduleId) return item;
      const file: ModuleFile = {
        id,
        name: uniqueFileName(
          cleanFileName(name),
          item.files.map((existing) => existing.name),
        ),
        content,
        createdAt: now,
        updatedAt: now,
      };
      return { ...item, files: [...item.files, file] };
    }),
  );
  return id;
}

/** Changes a file's name and/or code. */
export function updateFile(
  moduleId: string,
  fileId: string,
  changes: Partial<Pick<ModuleFile, "name" | "content">>,
) {
  store.set((modules) =>
    modules.map((item) => {
      if (item.id !== moduleId) return item;

      return {
        ...item,
        files: item.files.map((file) => {
          if (file.id !== fileId) return file;

          const others = item.files.filter((other) => other.id !== fileId).map((other) => other.name);
          return {
            ...file,
            name:
              changes.name === undefined
                ? file.name
                : uniqueFileName(cleanFileName(changes.name), others),
            content: changes.content ?? file.content,
            updatedAt: Date.now(),
          };
        }),
      };
    }),
  );
}

export function removeFile(moduleId: string, fileId: string) {
  store.set((modules) =>
    modules.map((item) =>
      item.id === moduleId
        ? { ...item, files: item.files.filter((file) => file.id !== fileId) }
        : item,
    ),
  );
}
