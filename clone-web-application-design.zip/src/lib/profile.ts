import { createPersistedStore } from "./persisted";
import { normalizeUrl } from "./url";

export interface ProfileData {
  name: string;
  studentId: string;
  university: string;
  section: string;
  semester: string;
  subject: string;
  professor: string;
  passingYear: string;
  /** Optional link to the student's GitHub. Empty when not set. */
  github: string;
  /** Portrait photo as a data URL. Empty when no photo has been uploaded. */
  photo: string;
}

export const DEFAULT_PROFILE: ProfileData = {
  name: "Kandukuru Pavitra",
  studentId: "24102A030044",
  university: "Mohan Babu University",
  section: "Section 1",
  semester: "Semester V",
  subject: "Data Science",
  professor: "Bosu Babu",
  passingYear: "2028",
  github: "https://github.com/kandukurupavithra",
  photo: "",
};

const REQUIRED_FIELDS = [
  "name",
  "studentId",
  "university",
  "section",
  "semester",
  "subject",
  "professor",
  "passingYear",
] as const;

/** Trims every value; empty required fields fall back to the defaults. */
function sanitize(input: Record<string, unknown>): ProfileData {
  const result: ProfileData = { ...DEFAULT_PROFILE };

  for (const field of REQUIRED_FIELDS) {
    const value = input[field];
    result[field] = typeof value === "string" && value.trim() ? value.trim() : DEFAULT_PROFILE[field];
  }

  // A cleared GitHub link stays empty; only a missing value falls back to the default.
  result.github =
    typeof input.github === "string" ? (normalizeUrl(input.github) ?? "") : DEFAULT_PROFILE.github;

  result.photo =
    typeof input.photo === "string" && input.photo.startsWith("data:image/") ? input.photo : "";

  return result;
}

const store = createPersistedStore<ProfileData>("ds-lab-workbench:profile", DEFAULT_PROFILE, (value) =>
  sanitize(typeof value === "object" && value !== null ? (value as Record<string, unknown>) : {}),
);

export const useProfile = store.useValue;

export function updateProfile(changes: Partial<ProfileData>) {
  store.set((current) => sanitize({ ...current, ...changes }));
}

/** "Kandukuru Pavitra" becomes "KP". */
export function getInitials(name: string): string {
  const letters = name
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((word) => word[0].toUpperCase());
  return letters.join("") || "S";
}
