import { useMemo } from "react";
import { experiments as baseExperiments } from "../data";
import type { Experiment, SubExperiment } from "../data/types";
import { parseImports } from "./modules";
import { createPersistedStore } from "./persisted";

/** Fields of an experiment the student can change. */
export type ExperimentEdit = Partial<
  Pick<
    Experiment,
    | "title"
    | "category"
    | "sem"
    | "subject"
    | "status"
    | "coverPhoto"
    | "overview"
    | "summary"
    | "videoUrl"
    | "githubLink"
  >
>;
export type ExperimentFields = Required<ExperimentEdit>;

/** Fields of a sub-experiment the student can change. */
export type SubEdit = Partial<
  Pick<SubExperiment, "title" | "overview" | "code" | "output" | "pythonLibs">
>;
export type SubFields = Pick<SubExperiment, "title" | "overview" | "code" | "output">;

/**
 * Everything the student changes in the browser (kept in localStorage): edits to the built-in
 * experiments and sub-experiments, plus anything added or removed.
 */
export interface LabState {
  experimentEdits: Record<number, ExperimentEdit>;
  deletedExperiments: number[];
  addedExperiments: Experiment[];
  /** Keyed by `${experimentId}:${subExpNumber}`. */
  subEdits: Record<string, SubEdit>;
  deletedSubs: string[];
  addedSubs: Record<number, SubExperiment[]>;
}

const EMPTY_STATE: LabState = {
  experimentEdits: {},
  deletedExperiments: [],
  addedExperiments: [],
  subEdits: {},
  deletedSubs: [],
  addedSubs: {},
};

export const subKey = (experimentId: number, subExpNumber: string) =>
  `${experimentId}:${subExpNumber}`;

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const asArray = <T>(value: unknown): T[] => (Array.isArray(value) ? (value as T[]) : []);

function normalize(value: unknown): LabState {
  if (!isRecord(value)) return EMPTY_STATE;

  const state: LabState = {
    experimentEdits: isRecord(value.experimentEdits)
      ? (value.experimentEdits as Record<number, ExperimentEdit>)
      : {},
    deletedExperiments: asArray<number>(value.deletedExperiments).filter(
      (id) => typeof id === "number",
    ),
    addedExperiments: asArray<Experiment>(value.addedExperiments).filter(
      (item) => item !== null && typeof item === "object" && typeof item.id === "number",
    ),
    subEdits: isRecord(value.subEdits) ? (value.subEdits as Record<string, SubEdit>) : {},
    deletedSubs: asArray<string>(value.deletedSubs).filter((key) => typeof key === "string"),
    addedSubs: isRecord(value.addedSubs)
      ? (value.addedSubs as Record<number, SubExperiment[]>)
      : {},
  };

  // Earlier versions saved edits as `codes`, `deleted` and `added`; carry them over.
  if (!("subEdits" in value)) {
    if (isRecord(value.codes)) {
      for (const [key, code] of Object.entries(value.codes)) {
        if (typeof code === "string") state.subEdits[key] = { code, output: "" };
      }
    }
    state.deletedSubs = asArray<string>(value.deleted).filter((key) => typeof key === "string");
    if (isRecord(value.added)) state.addedSubs = value.added as Record<number, SubExperiment[]>;
  }

  return state;
}

const store = createPersistedStore<LabState>("ds-lab-workbench:v1", EMPTY_STATE, normalize);

export const useLabState = store.useValue;

function omitNumberKey<T>(record: Record<number, T>, id: number): Record<number, T> {
  return Object.fromEntries(Object.entries(record).filter(([key]) => Number(key) !== id));
}

function omitPrefixed<T>(record: Record<string, T>, prefix: string): Record<string, T> {
  return Object.fromEntries(Object.entries(record).filter(([key]) => !key.startsWith(prefix)));
}

/** The built-in and added experiments with every edit applied and removed items left out. */
export function resolveExperiments(state: LabState): Experiment[] {
  const deletedExperiments = new Set(state.deletedExperiments);
  const deletedSubs = new Set(state.deletedSubs);

  return [...baseExperiments, ...state.addedExperiments]
    .filter((experiment) => !deletedExperiments.has(experiment.id))
    .map((experiment) => {
      const subExperiments = [
        ...experiment.subExperiments,
        ...(state.addedSubs[experiment.id] ?? []),
      ]
        .filter((sub) => !deletedSubs.has(subKey(experiment.id, sub.subExpNumber)))
        .map((sub) => {
          const edit = state.subEdits[subKey(experiment.id, sub.subExpNumber)];
          return edit ? { ...sub, ...edit } : sub;
        });

      return { ...experiment, ...state.experimentEdits[experiment.id], subExperiments };
    });
}

/** Every experiment as the student sees it. Updates the moment anything changes. */
export function useExperiments(): Experiment[] {
  const state = store.useValue();
  return useMemo(() => resolveExperiments(state), [state]);
}

/* ------------------------------ experiments ------------------------------ */

export function editExperiment(id: number, edit: ExperimentEdit) {
  store.set((state) => ({
    ...state,
    experimentEdits: {
      ...state.experimentEdits,
      [id]: { ...state.experimentEdits[id], ...edit },
    },
  }));
}

/** Creates an experiment and returns its id so the caller can open it. */
export function addExperiment(fields: ExperimentFields): number {
  const current = store.get();
  const ids = [...baseExperiments, ...current.addedExperiments].map((experiment) => experiment.id);
  const id = Math.max(0, ...ids) + 1;

  const experiment: Experiment = {
    ...fields,
    id,
    expNumber: `EXP-${String(id).padStart(2, "0")}`,
    code: "",
    output: "",
    pythonLibs: "",
    orderIndex: id,
    subExperiments: [],
  };

  store.set((state) => ({ ...state, addedExperiments: [...state.addedExperiments, experiment] }));
  return id;
}

/** Built-in experiments can be restored later; added ones are removed for good. */
export function deleteExperiment(id: number) {
  store.set((state) => {
    const isBuiltIn = baseExperiments.some((experiment) => experiment.id === id);
    if (isBuiltIn) {
      return state.deletedExperiments.includes(id)
        ? state
        : { ...state, deletedExperiments: [...state.deletedExperiments, id] };
    }

    const prefix = `${id}:`;
    return {
      ...state,
      addedExperiments: state.addedExperiments.filter((experiment) => experiment.id !== id),
      experimentEdits: omitNumberKey(state.experimentEdits, id),
      addedSubs: omitNumberKey(state.addedSubs, id),
      subEdits: omitPrefixed(state.subEdits, prefix),
      deletedSubs: state.deletedSubs.filter((key) => !key.startsWith(prefix)),
    };
  });
}

export function restoreExperiments() {
  store.set((state) => ({ ...state, deletedExperiments: [] }));
}

/* ---------------------------- sub-experiments ---------------------------- */

export function editSub(experimentId: number, subExpNumber: string, edit: SubEdit) {
  const key = subKey(experimentId, subExpNumber);
  // The module list follows the imports in the code.
  const next =
    edit.code === undefined ? edit : { ...edit, pythonLibs: parseImports(edit.code).join(", ") };

  store.set((state) => ({
    ...state,
    subEdits: { ...state.subEdits, [key]: { ...state.subEdits[key], ...next } },
  }));
}

/** Creates a sub-experiment and returns its number so the caller can open its tab. */
export function addSub(experimentId: number, fields: SubFields): string {
  const current = store.get();
  const experiment = [...baseExperiments, ...current.addedExperiments].find(
    (item) => item.id === experimentId,
  );
  if (!experiment) return "";

  const taken = new Set(
    [...experiment.subExperiments, ...(current.addedSubs[experimentId] ?? [])].map(
      (sub) => sub.subExpNumber,
    ),
  );
  let index = taken.size + 1;
  while (taken.has(`${experiment.expNumber}.${index}`)) index += 1;
  const subExpNumber = `${experiment.expNumber}.${index}`;

  const sub: SubExperiment = {
    ...fields,
    subExpNumber,
    pythonLibs: parseImports(fields.code).join(", "),
  };

  store.set((state) => ({
    ...state,
    addedSubs: {
      ...state.addedSubs,
      [experimentId]: [...(state.addedSubs[experimentId] ?? []), sub],
    },
  }));
  return subExpNumber;
}

/** Built-in sub-experiments can be restored later; added ones are removed for good. */
export function deleteSub(experimentId: number, subExpNumber: string) {
  const key = subKey(experimentId, subExpNumber);

  store.set((state) => {
    const added = state.addedSubs[experimentId] ?? [];
    if (added.some((sub) => sub.subExpNumber === subExpNumber)) {
      return {
        ...state,
        addedSubs: {
          ...state.addedSubs,
          [experimentId]: added.filter((sub) => sub.subExpNumber !== subExpNumber),
        },
        subEdits: omitKey(state.subEdits, key),
      };
    }

    return state.deletedSubs.includes(key)
      ? state
      : { ...state, deletedSubs: [...state.deletedSubs, key] };
  });
}

function omitKey<T>(record: Record<string, T>, key: string): Record<string, T> {
  return Object.fromEntries(Object.entries(record).filter(([name]) => name !== key));
}

export function restoreSubs(experimentId: number) {
  const prefix = `${experimentId}:`;
  store.set((state) => ({
    ...state,
    deletedSubs: state.deletedSubs.filter((key) => !key.startsWith(prefix)),
  }));
}
