import { useSyncExternalStore } from "react";

/**
 * A tiny localStorage-backed store shared by every component that uses it, so a change made on one
 * page (for example a saved profile) shows up everywhere straight away.
 */
export function createPersistedStore<T>(
  key: string,
  initial: T,
  normalize: (value: unknown) => T,
) {
  const load = (): T => {
    try {
      const raw = window.localStorage.getItem(key);
      return raw === null ? initial : normalize(JSON.parse(raw));
    } catch {
      return initial;
    }
  };

  let current = load();
  const listeners = new Set<() => void>();
  const emit = () => listeners.forEach((listener) => listener());

  const subscribe = (listener: () => void) => {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  };
  const getSnapshot = () => current;

  // Keep several open tabs in sync.
  window.addEventListener("storage", (event) => {
    if (event.key === key) {
      current = load();
      emit();
    }
  });

  return {
    useValue: () => useSyncExternalStore(subscribe, getSnapshot),
    get: getSnapshot,
    set(update: (previous: T) => T) {
      current = update(current);
      try {
        window.localStorage.setItem(key, JSON.stringify(current));
      } catch {
        // Storage can be full or blocked; the value still updates for this session.
      }
      emit();
    },
  };
}
