/** Largest text or code file that can be added. Everything is kept in the browser's storage. */
export const MAX_TEXT_FILE_BYTES = 500 * 1024;

/** Replaces characters that can't be used in a file name and trims the result. */
export function cleanFileName(name: string): string {
  const cleaned = name.trim().replace(/[\\/:*?"<>|]+/g, "_");
  return cleaned || "untitled";
}

/** Adds " (2)", " (3)" and so on before the extension until the name is not taken yet. */
export function uniqueFileName(name: string, taken: string[]): string {
  const used = new Set(taken.map((item) => item.toLowerCase()));
  if (!used.has(name.toLowerCase())) return name;

  const dot = name.lastIndexOf(".");
  const base = dot > 0 ? name.slice(0, dot) : name;
  const extension = dot > 0 ? name.slice(dot) : "";

  let counter = 2;
  while (used.has(`${base} (${counter})${extension}`.toLowerCase())) counter += 1;
  return `${base} (${counter})${extension}`;
}

const FILE_TYPES: Record<string, string> = {
  py: "Python",
  ipynb: "Notebook",
  js: "JavaScript",
  ts: "TypeScript",
  json: "JSON",
  csv: "CSV",
  md: "Markdown",
  txt: "Text",
  sql: "SQL",
  html: "HTML",
  css: "CSS",
  r: "R",
  sh: "Shell",
  yml: "YAML",
  yaml: "YAML",
};

/** A short label for the kind of file, based on its extension. */
export function describeFile(name: string): string {
  const dot = name.lastIndexOf(".");
  if (dot <= 0) return "File";
  return FILE_TYPES[name.slice(dot + 1).toLowerCase()] ?? "File";
}

export function countLines(text: string): number {
  return text === "" ? 0 : text.split("\n").length;
}

/** Reads a file chosen by the student as text. Rejects pictures, archives and other binary files. */
export async function readTextFile(file: File): Promise<string> {
  if (file.size > MAX_TEXT_FILE_BYTES) {
    throw new Error(`The file is too large (the limit is ${MAX_TEXT_FILE_BYTES / 1024} KB).`);
  }
  const text = await file.text();
  if (text.includes("\u0000")) {
    throw new Error("This does not look like a text or code file.");
  }
  return text.replace(/\r\n/g, "\n");
}
