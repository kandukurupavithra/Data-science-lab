import type { Experiment } from "../data/types";

export interface ModuleInfo {
  emoji: string;
  category: string;
  description: string;
  /** The usual way to import the module. */
  importLine: string;
  docsUrl?: string;
}

const stdlib = (name: string) => `https://docs.python.org/3/library/${name}.html`;

export const MODULE_CATALOG: Record<string, ModuleInfo> = {
  pandas: {
    emoji: "🐼",
    category: "Data analysis",
    description: "DataFrames and tabular data analysis",
    importLine: "import pandas as pd",
    docsUrl: "https://pandas.pydata.org/docs/",
  },
  numpy: {
    emoji: "🔢",
    category: "Data analysis",
    description: "Numerical arrays and maths",
    importLine: "import numpy as np",
    docsUrl: "https://numpy.org/doc/",
  },
  scipy: {
    emoji: "🔬",
    category: "Data analysis",
    description: "Scientific computing and statistics",
    importLine: "from scipy import stats",
    docsUrl: "https://docs.scipy.org/doc/scipy/",
  },
  matplotlib: {
    emoji: "📈",
    category: "Visualization",
    description: "Plots and charts",
    importLine: "import matplotlib.pyplot as plt",
    docsUrl: "https://matplotlib.org/stable/",
  },
  seaborn: {
    emoji: "🎨",
    category: "Visualization",
    description: "Statistical plots on top of Matplotlib",
    importLine: "import seaborn as sns",
    docsUrl: "https://seaborn.pydata.org",
  },
  sklearn: {
    emoji: "🤖",
    category: "Machine learning",
    description: "Machine-learning toolkit",
    importLine: "from sklearn.linear_model import LinearRegression",
    docsUrl: "https://scikit-learn.org/stable/",
  },
  json: {
    emoji: "🧾",
    category: "Files & databases",
    description: "JSON encoding and decoding",
    importLine: "import json",
    docsUrl: stdlib("json"),
  },
  csv: {
    emoji: "📄",
    category: "Files & databases",
    description: "CSV reading and writing",
    importLine: "import csv",
    docsUrl: stdlib("csv"),
  },
  openpyxl: {
    emoji: "📗",
    category: "Files & databases",
    description: "Excel (.xlsx) files",
    importLine: "import openpyxl",
    docsUrl: "https://openpyxl.readthedocs.io",
  },
  sqlite3: {
    emoji: "🗄️",
    category: "Files & databases",
    description: "Embedded SQL database",
    importLine: "import sqlite3",
    docsUrl: stdlib("sqlite3"),
  },
  requests: {
    emoji: "🌐",
    category: "Web & APIs",
    description: "HTTP requests and web APIs",
    importLine: "import requests",
    docsUrl: "https://requests.readthedocs.io",
  },
  urllib: {
    emoji: "🔗",
    category: "Web & APIs",
    description: "URL handling and downloads",
    importLine: "import urllib.request",
    docsUrl: stdlib("urllib"),
  },
  re: {
    emoji: "🔍",
    category: "Core Python",
    description: "Regular expressions",
    importLine: "import re",
    docsUrl: stdlib("re"),
  },
  io: {
    emoji: "🧵",
    category: "Core Python",
    description: "In-memory file streams",
    importLine: "import io",
    docsUrl: stdlib("io"),
  },
  os: {
    emoji: "🗂️",
    category: "Core Python",
    description: "Operating-system helpers",
    importLine: "import os",
    docsUrl: stdlib("os"),
  },
  sys: {
    emoji: "⚙️",
    category: "Core Python",
    description: "Interpreter and runtime info",
    importLine: "import sys",
    docsUrl: stdlib("sys"),
  },
  math: {
    emoji: "➗",
    category: "Core Python",
    description: "Mathematical functions",
    importLine: "import math",
    docsUrl: stdlib("math"),
  },
  random: {
    emoji: "🎲",
    category: "Core Python",
    description: "Random numbers",
    importLine: "import random",
    docsUrl: stdlib("random"),
  },
  datetime: {
    emoji: "📅",
    category: "Core Python",
    description: "Dates and times",
    importLine: "from datetime import datetime",
    docsUrl: stdlib("datetime"),
  },
};

export function getModuleInfo(name: string): ModuleInfo {
  return (
    MODULE_CATALOG[name] ?? {
      emoji: "🧩",
      category: "Other",
      description: "Python module",
      importLine: `import ${name}`,
    }
  );
}

export function describeModule(name: string): string {
  return getModuleInfo(name).description;
}

/** Finds the top-level modules imported by a Python program. */
export function parseImports(code: string): string[] {
  const found: string[] = [];

  for (const line of code.split("\n")) {
    const fromMatch = /^\s*from\s+([A-Za-z_]\w*)[\w.]*\s+import\s/.exec(line);
    if (fromMatch) {
      found.push(fromMatch[1]);
      continue;
    }

    const importMatch = /^\s*import\s+(.+)$/.exec(line);
    if (importMatch) {
      for (const part of importMatch[1].split(",")) {
        const name = part.trim().split(/\s+as\s+/)[0].split(".")[0].trim();
        if (/^[A-Za-z_]\w*$/.test(name)) found.push(name);
      }
    }
  }

  return Array.from(new Set(found));
}

export interface ModuleUsage {
  name: string;
  /** Experiments that use the module (in the main experiment or any sub-experiment). */
  experiments: Array<{ id: number; expNumber: string }>;
  /** How many sub-experiments use the module. */
  subCount: number;
}

const splitList = (value: string) =>
  value
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);

/**
 * Lists every module used across the experiments, most used first. Sub-experiments are read from
 * their code, so edits and newly added sub-experiments are counted too.
 */
export function collectModuleUsage(experiments: Experiment[]): ModuleUsage[] {
  const usage = new Map<string, ModuleUsage>();

  const touch = (name: string, experiment: Experiment, inSub: boolean) => {
    let entry = usage.get(name);
    if (!entry) {
      entry = { name, experiments: [], subCount: 0 };
      usage.set(name, entry);
    }
    if (!entry.experiments.some((item) => item.id === experiment.id)) {
      entry.experiments.push({ id: experiment.id, expNumber: experiment.expNumber });
    }
    if (inSub) entry.subCount += 1;
  };

  for (const experiment of experiments) {
    splitList(experiment.pythonLibs).forEach((name) => touch(name, experiment, false));
    for (const sub of experiment.subExperiments) {
      const names = new Set([...parseImports(sub.code), ...splitList(sub.pythonLibs)]);
      names.forEach((name) => touch(name, experiment, true));
    }
  }

  const weight = (entry: ModuleUsage) => entry.subCount + entry.experiments.length;
  return Array.from(usage.values()).sort(
    (a, b) => weight(b) - weight(a) || a.name.localeCompare(b.name),
  );
}
