import { createPersistedStore } from "./persisted";

export type ProjectStatus = "Idea" | "In progress" | "Completed";

export const PROJECT_STATUSES: ProjectStatus[] = ["Idea", "In progress", "Completed"];

export interface Project {
  id: string;
  title: string;
  description: string;
  status: ProjectStatus;
  createdAt: number;
}

function isProject(value: unknown): value is Project {
  if (typeof value !== "object" || value === null) return false;
  const item = value as Record<string, unknown>;
  return (
    typeof item.id === "string" &&
    typeof item.title === "string" &&
    typeof item.description === "string" &&
    typeof item.createdAt === "number" &&
    PROJECT_STATUSES.includes(item.status as ProjectStatus)
  );
}

const store = createPersistedStore<Project[]>("ds-lab-workbench:projects", [], (value) =>
  Array.isArray(value) ? value.filter(isProject) : [],
);

export const useProjects = store.useValue;

export function addProject(title: string, description: string, status: ProjectStatus) {
  const project: Project = {
    id: `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
    title,
    description,
    status,
    createdAt: Date.now(),
  };
  store.set((projects) => [project, ...projects]);
}

export function updateProjectStatus(id: string, status: ProjectStatus) {
  store.set((projects) =>
    projects.map((project) => (project.id === id ? { ...project, status } : project)),
  );
}

export function updateProject(
  id: string,
  changes: Partial<Pick<Project, "title" | "description" | "status">>,
) {
  store.set((projects) =>
    projects.map((project) => (project.id === id ? { ...project, ...changes } : project)),
  );
}

export function removeProject(id: string) {
  store.set((projects) => projects.filter((project) => project.id !== id));
}
