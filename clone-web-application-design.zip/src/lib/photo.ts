const PHOTO_WIDTH = 360;
const PHOTO_HEIGHT = 480; // portrait 3:4, like an ID photo
const MAX_FILE_BYTES = 15 * 1024 * 1024;

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () =>
      reject(new Error("That file could not be read as an image. Try a JPG or PNG photo."));
    image.src = src;
  });
}

/**
 * Turns a chosen picture into a small portrait JPEG (as a data URL) that fits comfortably in the
 * browser's storage. The picture is cropped to 3:4 around the upper-centre, where faces usually are.
 */
export async function readPhotoFile(file: File): Promise<string> {
  if (!file.type.startsWith("image/")) {
    throw new Error("Please choose an image file (JPG or PNG).");
  }
  if (file.size > MAX_FILE_BYTES) {
    throw new Error("That image is too large. Please choose one under 15 MB.");
  }

  const url = URL.createObjectURL(file);
  try {
    const image = await loadImage(url);

    const canvas = document.createElement("canvas");
    canvas.width = PHOTO_WIDTH;
    canvas.height = PHOTO_HEIGHT;
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Your browser could not process the photo.");

    // Scale to cover the frame, then crop the overflow.
    const scale = Math.max(PHOTO_WIDTH / image.width, PHOTO_HEIGHT / image.height);
    const cropWidth = PHOTO_WIDTH / scale;
    const cropHeight = PHOTO_HEIGHT / scale;
    const cropX = (image.width - cropWidth) / 2;
    const cropY = (image.height - cropHeight) * 0.25;

    context.fillStyle = "#ffffff";
    context.fillRect(0, 0, PHOTO_WIDTH, PHOTO_HEIGHT);
    context.drawImage(image, cropX, cropY, cropWidth, cropHeight, 0, 0, PHOTO_WIDTH, PHOTO_HEIGHT);

    return canvas.toDataURL("image/jpeg", 0.86);
  } finally {
    URL.revokeObjectURL(url);
  }
}
