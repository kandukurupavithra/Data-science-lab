import JSZip from "jszip";
import type { Experiment } from "../data/types";
import { cleanFileName } from "./files";
import type { LearningModule } from "./learning";

function slug(value: string) {
  return value.replace(/[^a-zA-Z0-9]+/g, "_").replace(/^_+|_+$/g, "");
}

function buildReadme(experiments: Experiment[], modules: LearningModule[]) {
  const lines = [
    "# Data Science Lab",
    "",
    "Computational Intelligence & Analytics Workbench",
    "",
    "Practical laboratory record for Machine Learning & Empirical Data Analytics.",
    "",
    "## Experiments",
    "",
    ...experiments.map(
      (experiment) =>
        `- **${experiment.expNumber}** ${experiment.title} (${experiment.subExperiments.length} sub-experiments)`,
    ),
    "",
  ];

  if (modules.length > 0) {
    lines.push(
      "## Learning modules",
      "",
      ...modules.map(
        (item) => `- **${item.title}** (${item.topics.length} topics, ${item.files.length} files)`,
      ),
      "",
    );
  }
  return lines.join("\n");
}

function buildExperimentReadme(experiment: Experiment) {
  const lines = [`# ${experiment.expNumber}: ${experiment.title}`, ""];
  if (experiment.summary) lines.push("## Summary", "", experiment.summary, "");
  lines.push("## Overview", "", experiment.overview, "");
  if (experiment.videoUrl) lines.push(`Video: ${experiment.videoUrl}`);
  if (experiment.githubLink) lines.push(`GitHub: ${experiment.githubLink}`);
  lines.push("");
  return lines.join("\n");
}

function buildModuleReadme(item: LearningModule) {
  const lines = [`# ${item.title}`, ""];
  if (item.description) lines.push(item.description, "");

  if (item.topics.length > 0) {
    lines.push("## Topics", "");
    for (const topic of item.topics) {
      lines.push(`- [${topic.done ? "x" : " "}] ${topic.title}`);
      if (topic.notes) lines.push(...topic.notes.split("\n").map((line) => `    ${line}`));
    }
    lines.push("");
  }

  if (item.files.length > 0) {
    lines.push("## Files", "", ...item.files.map((file) => `- files/${file.name}`), "");
  }
  return lines.join("\n");
}

/** Bundles the experiments, their sub-experiment programs and the learning modules into a ZIP and downloads it. */
export async function downloadLabArchive(
  experiments: Experiment[],
  modules: LearningModule[] = [],
) {
  const zip = new JSZip();
  const root = zip.folder("data-science-lab")!;
  root.file("README.md", buildReadme(experiments, modules));

  for (const experiment of experiments) {
    const folder = root.folder(`${experiment.expNumber}_${slug(experiment.title)}`)!;
    folder.file("README.md", buildExperimentReadme(experiment));

    for (const sub of experiment.subExperiments) {
      const subFolder = folder.folder(slug(sub.subExpNumber))!;
      subFolder.file("README.md", `# ${sub.subExpNumber}: ${sub.title}\n\n${sub.overview}\n`);
      subFolder.file("program.py", sub.code);
      if (sub.output.trim()) subFolder.file("output.txt", sub.output);
    }
  }

  if (modules.length > 0) {
    const learning = root.folder("learning_modules")!;
    modules.forEach((item, index) => {
      const folder = learning.folder(
        `${String(index + 1).padStart(2, "0")}_${slug(item.title) || "module"}`,
      )!;
      folder.file("README.md", buildModuleReadme(item));
      for (const file of item.files) {
        folder.file(`files/${cleanFileName(file.name)}`, file.content);
      }
    });
  }

  const blob = await zip.generateAsync({ type: "blob" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "data-science-lab.zip";
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
