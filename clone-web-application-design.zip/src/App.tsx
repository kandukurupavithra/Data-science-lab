import { ArrowLeft } from "lucide-react";
import { ExperimentDetail } from "./components/ExperimentDetail";
import { Experiments } from "./components/Experiments";
import { Home } from "./components/Home";
import { ModuleDetail } from "./components/ModuleDetail";
import { Modules } from "./components/Modules";
import { Profile } from "./components/Profile";
import { Projects } from "./components/Projects";
import { MobileNav, Sidebar } from "./components/Sidebar";
import { SplineBackground } from "./components/SplineBackground";
import { Tools } from "./components/Tools";
import { Topbar } from "./components/Topbar";
import { useExperiments } from "./lib/labStore";
import { useRoute, type PageName, type Route } from "./lib/router";

/** Which menu item to highlight. Detail pages belong to their section. */
function activePage(route: Route): PageName {
  if (route.page === "experiment") return "experiments";
  if (route.page === "module") return "modules";
  return route.page;
}

export default function App() {
  const route = useRoute();
  const active = activePage(route);

  return (
    <div className="relative isolate min-h-screen text-ink antialiased">
      <SplineBackground />
      <div className="flex min-h-screen">
        <Sidebar active={active} />
        <div className="min-w-0 flex-1">
          <MobileNav active={active} />
          <main className="mx-auto w-full max-w-6xl space-y-8 px-4 pb-20 pt-8 sm:px-8 lg:px-10 lg:pt-10">
            <Topbar />
            <Page route={route} />
          </main>
        </div>
      </div>
    </div>
  );
}

function Page({ route }: { route: Route }) {
  switch (route.page) {
    case "home":
      return <Home />;
    case "experiments":
      return <Experiments />;
    case "projects":
      return <Projects />;
    case "tools":
      return <Tools />;
    case "modules":
      return <Modules />;
    case "profile":
      return <Profile />;
    case "module":
      return <ModuleDetail id={route.id} />;
    case "experiment":
      return <ExperimentPage id={route.id} sub={route.sub} />;
  }
}

function ExperimentPage({ id, sub }: { id: number; sub: string | null }) {
  const experiments = useExperiments();
  const experiment = experiments.find((item) => item.id === id);

  if (!experiment) {
    return (
      <div className="rounded-3xl border border-dashed border-brand-200 bg-white p-10 text-center">
        <p className="text-lg font-bold text-ink">Experiment not found</p>
        <a
          href="#/experiments"
          className="mt-4 inline-flex items-center gap-2 text-sm font-bold text-brand-600 hover:text-brand-700"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to experiments
        </a>
      </div>
    );
  }

  // The key resets the tab state when moving to another experiment.
  return <ExperimentDetail key={experiment.id} experiment={experiment} activeSub={sub} />;
}
