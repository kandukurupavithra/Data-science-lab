import { useState, type ChangeEvent, type FormEvent } from "react";
import type { Experiment } from "../data/types";
import type { ExperimentFields } from "../lib/labStore";
import { useProfile } from "../lib/profile";
import { normalizeUrl } from "../lib/url";
import { Field, FormButtons, FormCard, INPUT_CLASS } from "./form";

interface Values {
  title: string;
  category: string;
  sem: string;
  subject: string;
  status: string;
  coverPhoto: string;
  overview: string;
  summary: string;
  videoUrl: string;
  githubLink: string;
}

type InputEvent = ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>;

const STATUSES = ["In progress", "Completed"];

interface ExperimentFormProps {
  /** The experiment being edited, or null when creating a new one. */
  initial: Experiment | null;
  /** Existing categories, offered as suggestions. */
  categories: string[];
  heading: string;
  submitLabel: string;
  onSubmit: (fields: ExperimentFields) => void;
  onCancel: () => void;
}

export function ExperimentForm({
  initial,
  categories,
  heading,
  submitLabel,
  onSubmit,
  onCancel,
}: ExperimentFormProps) {
  const profile = useProfile();
  const [values, setValues] = useState<Values>(() => ({
    title: initial?.title ?? "",
    category: initial?.category ?? categories[0] ?? "General",
    sem: initial?.sem ?? profile.semester,
    subject: initial?.subject ?? profile.subject,
    status: initial?.status ?? "In progress",
    coverPhoto: initial?.coverPhoto ?? "",
    overview: initial?.overview ?? "",
    summary: initial?.summary ?? "",
    videoUrl: initial?.videoUrl ?? "",
    githubLink: initial?.githubLink ?? "",
  }));

  const bind = (key: keyof Values) => ({
    value: values[key],
    onChange: (event: InputEvent) => {
      const next = event.target.value;
      setValues((current) => ({ ...current, [key]: next }));
    },
  });

  const statusOptions = STATUSES.includes(values.status) ? STATUSES : [...STATUSES, values.status];

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (!values.title.trim()) return;
    onSubmit({
      title: values.title.trim(),
      category: values.category.trim() || "General",
      sem: values.sem.trim(),
      subject: values.subject.trim(),
      status: values.status,
      coverPhoto: normalizeUrl(values.coverPhoto) ?? "",
      overview: values.overview.trim(),
      summary: values.summary.trim() || null,
      videoUrl: normalizeUrl(values.videoUrl),
      githubLink: normalizeUrl(values.githubLink),
    });
  }

  return (
    <FormCard title={heading} onSubmit={handleSubmit}>
      <Field label="Title">
        <input
          autoFocus
          {...bind("title")}
          placeholder="e.g. Data Wrangling"
          className={INPUT_CLASS}
        />
      </Field>

      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Category">
          <input {...bind("category")} list="experiment-categories" className={INPUT_CLASS} />
          <datalist id="experiment-categories">
            {categories.map((item) => (
              <option key={item} value={item} />
            ))}
          </datalist>
        </Field>
        <Field label="Status">
          <select {...bind("status")} className={INPUT_CLASS}>
            {statusOptions.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Semester">
          <input {...bind("sem")} className={INPUT_CLASS} />
        </Field>
        <Field label="Subject">
          <input {...bind("subject")} className={INPUT_CLASS} />
        </Field>
      </div>

      <Field label="Overview">
        <textarea
          rows={3}
          {...bind("overview")}
          placeholder="What is this experiment about?"
          className={INPUT_CLASS}
        />
      </Field>

      <Field label="Summary">
        <textarea
          rows={2}
          {...bind("summary")}
          placeholder="What did you learn? (optional)"
          className={INPUT_CLASS}
        />
      </Field>

      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="YouTube link" hint="Optional. A watch or youtu.be link embeds the video.">
          <input {...bind("videoUrl")} placeholder="https://www.youtube.com/watch?v=…" className={INPUT_CLASS} />
        </Field>
        <Field label="GitHub link" hint="Optional.">
          <input {...bind("githubLink")} placeholder="https://github.com/…" className={INPUT_CLASS} />
        </Field>
      </div>

      <Field label="Cover image link" hint="Optional. Leave empty for a purple gradient.">
        <input {...bind("coverPhoto")} placeholder="https://…" className={INPUT_CLASS} />
      </Field>

      <FormButtons submitLabel={submitLabel} disabled={!values.title.trim()} onCancel={onCancel} />
    </FormCard>
  );
}
