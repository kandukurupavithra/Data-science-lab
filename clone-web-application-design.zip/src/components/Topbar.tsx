import { useState } from "react";
import { Download } from "lucide-react";
import { useExperiments } from "../lib/labStore";
import { useLearningModules } from "../lib/learning";
import { getInitials, useProfile } from "../lib/profile";
import { downloadLabArchive } from "../lib/zip";

export function Topbar() {
  const profile = useProfile();
  const experiments = useExperiments();
  const learningModules = useLearningModules();
  const [preparing, setPreparing] = useState(false);

  async function handleDownload() {
    setPreparing(true);
    try {
      // The archive holds the experiments and learning modules as you see them, with their files.
      await downloadLabArchive(experiments, learningModules);
    } finally {
      setPreparing(false);
    }
  }

  return (
    <header className="flex items-start justify-between gap-4">
      <div className="min-w-0">
        <p className="text-2xl font-bold tracking-tight text-ink sm:text-[1.7rem]">Data Science Lab</p>
        <p className="mt-1 text-sm text-muted sm:text-base">
          Computational Intelligence & Analytics Workbench
        </p>
      </div>

      <div className="flex shrink-0 items-center gap-3">
        <button
          type="button"
          onClick={handleDownload}
          disabled={preparing}
          title="Download complete project files as a .ZIP archive"
          className="inline-flex items-center gap-2 rounded-xl border border-brand-200 bg-white px-3.5 py-2.5 text-sm font-semibold text-brand-700 shadow-sm transition hover:bg-brand-50 disabled:cursor-wait disabled:opacity-70"
        >
          <Download className="h-4 w-4" />
          <span className="hidden sm:inline">{preparing ? "Preparing…" : "Download ZIP"}</span>
        </button>
        <a
          href="#/profile"
          title={profile.name}
          aria-label="Open profile"
          className="flex h-12 w-12 items-center justify-center overflow-hidden rounded-full bg-brand-600 text-base font-bold text-white shadow-md shadow-brand-200 ring-2 ring-white transition hover:bg-brand-700 sm:h-14 sm:w-14"
        >
          {profile.photo ? (
            <img src={profile.photo} alt="" className="h-full w-full object-cover" />
          ) : (
            getInitials(profile.name)
          )}
        </a>
      </div>
    </header>
  );
}
