import { useEffect, useState } from "react";

type Point = [number, number];

interface Bundle {
  centerY: number;
  amplitude: number;
  period: number;
  phase: number;
  count: number;
  minSpread: number;
  maxSpread: number;
  tilt: number;
  /** Stroke colours handed out to the lines of this bundle in turn. */
  palette: string[];
}

interface Line {
  id: string;
  /** The same spline in three different poses; the line morphs between them. */
  frames: [string, string, string];
  color: string;
  width: number;
  opacity: number;
  duration: number;
  begin: number;
}

const X_START = -200;
const X_STEP = 200;
const POINTS = 11; // x runs from -200 to 1800 across a 1600-wide view box
const FRAME_PHASE = 1.1;

const PURPLE = ["#7e22ce", "#a855f7", "#c084fc", "#9333ea", "#d8b4fe"];

// Three bundles of hair-thin lines in purple, white and cream.
const BUNDLES: Bundle[] = [
  {
    centerY: 280,
    amplitude: 120,
    period: 1500,
    phase: 0,
    count: 11,
    minSpread: 5,
    maxSpread: 30,
    tilt: 140,
    palette: [PURPLE[0], "#ffffff", PURPLE[1], "#ece0bd", PURPLE[2], "#ffffff", PURPLE[3], PURPLE[4]],
  },
  {
    centerY: 700,
    amplitude: 100,
    period: 1300,
    phase: 2.2,
    count: 9,
    minSpread: 4,
    maxSpread: 26,
    tilt: -120,
    palette: [PURPLE[1], "#ffffff", PURPLE[0], "#e9d9b0", PURPLE[2], "#ffffff", PURPLE[3]],
  },
  {
    centerY: 500,
    amplitude: 160,
    period: 1900,
    phase: 4,
    count: 4,
    minSpread: 14,
    maxSpread: 60,
    tilt: 20,
    palette: ["#ffffff", "#e6d3a1", PURPLE[2], "#ffffff"],
  },
];

/** Converts points into smooth cubic Bézier segments (uniform Catmull-Rom spline). */
function smoothPath(points: Point[]): string {
  const [startX, startY] = points[0];
  let path = `M${startX} ${startY.toFixed(1)}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[Math.max(i - 1, 0)];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[Math.min(i + 2, points.length - 1)];
    const c1x = p1[0] + (p2[0] - p0[0]) / 6;
    const c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6;
    const c2y = p2[1] - (p3[1] - p1[1]) / 6;
    path += ` C${c1x.toFixed(1)} ${c1y.toFixed(1)} ${c2x.toFixed(1)} ${c2y.toFixed(1)} ${p2[0]} ${p2[1].toFixed(1)}`;
  }
  return path;
}

function buildFrame(bundle: Bundle, lineIndex: number, frame: number): string {
  const offset = lineIndex - (bundle.count - 1) / 2;
  const points: Point[] = [];

  for (let j = 0; j < POINTS; j++) {
    const x = X_START + j * X_STEP;
    const shift = frame * FRAME_PHASE;
    const wave = Math.sin((x / bundle.period) * Math.PI * 2 + bundle.phase + shift);
    const ripple =
      Math.sin((x / (bundle.period * 0.55)) * Math.PI * 2 + bundle.phase * 1.7 + shift * 1.3) * 0.35;
    const centre =
      bundle.centerY + (bundle.tilt * (x - 800)) / 800 + bundle.amplitude * (wave + ripple);
    // The gap between neighbouring lines opens and closes along the bundle.
    const pinch =
      0.5 + 0.5 * Math.sin((x / (bundle.period * 0.8)) * Math.PI * 2 + bundle.phase + 1.2 + frame * 0.9);
    const spread = bundle.minSpread + (bundle.maxSpread - bundle.minSpread) * pinch;
    points.push([x, centre + offset * spread]);
  }

  return smoothPath(points);
}

function buildLines(): Line[] {
  const lines: Line[] = [];
  let counter = 0;

  BUNDLES.forEach((bundle, bundleIndex) => {
    for (let i = 0; i < bundle.count; i++) {
      const color = bundle.palette[i % bundle.palette.length];
      const isLight = color === "#ffffff" || color.startsWith("#e");
      lines.push({
        id: `${bundleIndex}-${i}`,
        frames: [buildFrame(bundle, i, 0), buildFrame(bundle, i, 1), buildFrame(bundle, i, 2)],
        color,
        width: 0.8 + (i % 3) * 0.35, // 0.8px – 1.5px
        opacity: isLight ? 0.95 : 0.35 + ((i * 7) % 5) * 0.08,
        duration: 22 + ((counter * 3.7) % 14),
        begin: (counter * 2.3) % 12,
      });
      counter += 1;
    }
  });

  return lines;
}

const LINES = buildLines();

// Soft purple glows and a cream-to-white wash behind the lines.
const BASE_BACKGROUND = [
  "radial-gradient(60% 55% at 8% 10%, rgba(192, 132, 252, 0.28), transparent 70%)",
  "radial-gradient(55% 50% at 94% 90%, rgba(126, 34, 206, 0.2), transparent 70%)",
  "radial-gradient(50% 45% at 62% 6%, rgba(255, 255, 255, 0.95), transparent 70%)",
  "linear-gradient(160deg, #ffffff 0%, #fbf5e6 38%, #f5ead0 72%, #efe4fa 100%)",
].join(", ");

function usePrefersReducedMotion() {
  const [reduced, setReduced] = useState(
    () => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  );

  useEffect(() => {
    const query = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onChange = () => setReduced(query.matches);
    query.addEventListener("change", onChange);
    return () => query.removeEventListener("change", onChange);
  }, []);

  return reduced;
}

/**
 * Full-screen background of thin spline lines in purple, white and cream.
 * Each line slowly morphs between three poses; strokes keep a constant on-screen width.
 */
export function SplineBackground() {
  const reduced = usePrefersReducedMotion();

  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 -z-10 overflow-hidden"
      style={{ background: BASE_BACKGROUND }}
    >
      <svg
        className="absolute inset-0 h-full w-full"
        viewBox="0 0 1600 1000"
        preserveAspectRatio="xMidYMid slice"
      >
        {LINES.map((line) => (
          <path
            key={line.id}
            d={line.frames[0]}
            fill="none"
            stroke={line.color}
            strokeOpacity={line.opacity}
            strokeWidth={line.width}
            strokeLinecap="round"
            vectorEffect="non-scaling-stroke"
          >
            {!reduced && (
              <animate
                attributeName="d"
                dur={`${line.duration.toFixed(1)}s`}
                begin={`-${line.begin.toFixed(1)}s`}
                repeatCount="indefinite"
                calcMode="spline"
                keyTimes="0;0.333;0.666;1"
                keySplines="0.45 0 0.55 1;0.45 0 0.55 1;0.45 0 0.55 1"
                values={[line.frames[0], line.frames[1], line.frames[2], line.frames[0]].join(";")}
              />
            )}
          </path>
        ))}
      </svg>
    </div>
  );
}
