import type { FormEvent, ReactNode } from "react";
import { cn } from "../utils/cn";

export const INPUT_CLASS =
  "w-full rounded-xl border border-brand-100 bg-white px-3.5 py-2.5 text-sm text-ink outline-none transition placeholder:text-muted focus:border-brand-400 focus:ring-4 focus:ring-brand-100";

export function Field({
  label,
  hint,
  className,
  children,
}: {
  label: string;
  hint?: string;
  className?: string;
  children: ReactNode;
}) {
  return (
    <label className={cn("block space-y-1.5", className)}>
      <span className="text-sm font-semibold text-ink">{label}</span>
      {children}
      {hint && <span className="block text-xs text-muted">{hint}</span>}
    </label>
  );
}

export function FormCard({
  title,
  onSubmit,
  children,
}: {
  title: string;
  onSubmit: (event: FormEvent) => void;
  children: ReactNode;
}) {
  return (
    <form
      onSubmit={onSubmit}
      className="space-y-5 rounded-3xl border border-brand-100 bg-white/95 p-6 shadow-sm backdrop-blur-sm"
    >
      <h2 className="text-lg font-bold text-ink">{title}</h2>
      {children}
    </form>
  );
}

export function FormButtons({
  submitLabel,
  disabled,
  onCancel,
}: {
  submitLabel: string;
  disabled?: boolean;
  onCancel: () => void;
}) {
  return (
    <div className="flex flex-wrap items-center gap-3">
      <button
        type="submit"
        disabled={disabled}
        className="rounded-xl bg-brand-600 px-6 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-50"
      >
        {submitLabel}
      </button>
      <button
        type="button"
        onClick={onCancel}
        className="rounded-xl border border-brand-100 bg-white px-5 py-2.5 text-sm font-semibold text-muted transition hover:bg-brand-50"
      >
        Cancel
      </button>
    </div>
  );
}
