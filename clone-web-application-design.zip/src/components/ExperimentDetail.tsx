import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, Pencil, Trash2 } from "lucide-react";
import type { Experiment, SubExperiment } from "../data/types";
import {
  addSub,
  deleteExperiment,
  deleteSub,
  editExperiment,
  editSub,
  restoreSubs,
  useExperiments,
  useLabState,
} from "../lib/labStore";
import { collectModuleUsage, parseImports } from "../lib/modules";
import { experimentHref } from "../lib/router";
import { ExperimentForm } from "./ExperimentForm";
import { ExperimentTabs } from "./ExperimentTabs";
import { LabSidebar } from "./LabSidebar";
import { MainExperimentView } from "./MainExperimentView";
import { SubExperimentView } from "./SubExperimentView";
import { SubForm } from "./SubForm";
import { splitLibs } from "./ui";

interface ExperimentDetailProps {
  experiment: Experiment;
  /** Number of the sub-experiment tab to open, or null for the main experiment tab. */
  activeSub: string | null;
}

const EMPTY_SUB = { title: "", overview: "", code: "", output: "" };

export function ExperimentDetail({ experiment, activeSub }: ExperimentDetailProps) {
  const lab = useLabState();
  const allExperiments = useExperiments();
  const [addOpen, setAddOpen] = useState(false);
  const [editing, setEditing] = useState(false);

  const subs = experiment.subExperiments;
  const active = activeSub ? (subs.find((sub) => sub.subExpNumber === activeSub) ?? null) : null;
  const removedCount = lab.deletedSubs.filter((key) => key.startsWith(`${experiment.id}:`)).length;

  const categories = useMemo(
    () => Array.from(new Set(allExperiments.map((item) => item.category))),
    [allExperiments],
  );
  const mainModules = useMemo(
    () => collectModuleUsage([experiment]).map((usage) => usage.name),
    [experiment],
  );

  // A link to a removed or unknown sub-experiment falls back to the main tab.
  useEffect(() => {
    if (activeSub && !active) window.location.replace(experimentHref(experiment.id));
  }, [activeSub, active, experiment.id]);

  // The sidebar lists the modules of the open tab.
  let modules = mainModules;
  let scope = experiment.expNumber;
  if (active) {
    const imported = parseImports(active.code);
    modules = imported.length > 0 ? imported : splitLibs(active.pythonLibs);
    scope = active.subExpNumber;
  }

  function handleDeleteSub(sub: SubExperiment) {
    const isAdded = (lab.addedSubs[experiment.id] ?? []).some(
      (item) => item.subExpNumber === sub.subExpNumber,
    );
    const confirmed = window.confirm(
      `Delete ${sub.subExpNumber}: ${sub.title}?\n\n${
        isAdded ? "This cannot be undone." : 'You can bring it back with "Restore removed".'
      }`,
    );
    if (!confirmed) return;
    if (activeSub === sub.subExpNumber) window.location.hash = experimentHref(experiment.id);
    deleteSub(experiment.id, sub.subExpNumber);
  }

  function handleAddSub(values: Pick<SubExperiment, "title" | "overview" | "code" | "output">) {
    const subExpNumber = addSub(experiment.id, values);
    setAddOpen(false);
    if (subExpNumber) window.location.hash = experimentHref(experiment.id, subExpNumber);
  }

  function handleDeleteExperiment() {
    const count = subs.length;
    const confirmed = window.confirm(
      `Delete ${experiment.expNumber}: ${experiment.title}?\n\n` +
        `Its ${count} sub-experiment${count === 1 ? "" : "s"} go with it. ` +
        `You can bring the built-in experiments back with "Restore deleted" on the Experiments page.`,
    );
    if (!confirmed) return;
    window.location.hash = "#/experiments";
    deleteExperiment(experiment.id);
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <a
          href="#/experiments"
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 transition hover:text-purple-700"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to experiments
        </a>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setEditing((value) => !value)}
            aria-expanded={editing}
            className="inline-flex items-center gap-1.5 rounded-xl border border-brand-200 bg-white px-3.5 py-2 text-sm font-semibold text-brand-700 shadow-sm transition hover:bg-brand-50"
          >
            <Pencil className="h-4 w-4" />
            Edit experiment
          </button>
          <button
            type="button"
            onClick={handleDeleteExperiment}
            className="inline-flex items-center gap-1.5 rounded-xl border border-rose-200 bg-white px-3.5 py-2 text-sm font-semibold text-rose-600 shadow-sm transition hover:bg-rose-50"
          >
            <Trash2 className="h-4 w-4" />
            Delete
          </button>
        </div>
      </div>

      {editing && (
        <ExperimentForm
          initial={experiment}
          categories={categories}
          heading={`Edit ${experiment.expNumber}`}
          submitLabel="Save changes"
          onSubmit={(fields) => {
            editExperiment(experiment.id, fields);
            setEditing(false);
          }}
          onCancel={() => setEditing(false)}
        />
      )}

      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand-700 via-purple-900 to-slate-950 shadow-xl shadow-purple-200/60">
        {experiment.coverPhoto && (
          <img
            src={experiment.coverPhoto}
            alt=""
            className="absolute inset-0 h-full w-full object-cover opacity-60"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/55 to-black/30" />
        <div className="relative space-y-4 px-6 pb-8 pt-16 sm:px-8 sm:pt-20">
          <div className="flex flex-wrap items-center gap-2.5 text-sm font-semibold">
            <span className="rounded-lg border border-purple-400 bg-purple-700 px-3 py-1 text-white">
              {experiment.expNumber}
            </span>
            <span className="rounded-lg bg-slate-700/85 px-3 py-1 text-white">{experiment.category}</span>
            <span className="rounded-lg bg-slate-800/80 px-3 py-1 font-medium text-slate-200">
              {experiment.sem} • {experiment.subject}
            </span>
          </div>
          <h1 className="font-serif text-3xl font-bold uppercase leading-tight tracking-tight text-white sm:text-4xl lg:text-5xl">
            {experiment.title}
          </h1>
        </div>
      </section>

      <ExperimentTabs
        experiment={experiment}
        subs={subs}
        activeSub={active ? active.subExpNumber : null}
        addOpen={addOpen}
        removedCount={removedCount}
        onToggleAdd={() => setAddOpen((open) => !open)}
        onDelete={handleDeleteSub}
        onRestore={() => restoreSubs(experiment.id)}
      />

      {addOpen && (
        <SubForm
          initial={EMPTY_SUB}
          heading={`New sub-experiment in ${experiment.expNumber}`}
          submitLabel="Add sub-experiment"
          onSubmit={handleAddSub}
          onCancel={() => setAddOpen(false)}
        />
      )}

      <div className="grid gap-6 lg:grid-cols-[17rem_minmax(0,1fr)] lg:items-start">
        <LabSidebar
          modules={modules}
          scope={scope}
          className="order-2 lg:sticky lg:top-6 lg:order-1"
        />
        <div className="order-1 min-w-0 lg:order-2">
          {active ? (
            <SubExperimentView
              key={active.subExpNumber}
              sub={active}
              onSave={(values) => editSub(experiment.id, active.subExpNumber, values)}
              onDelete={() => handleDeleteSub(active)}
            />
          ) : (
            <MainExperimentView experiment={experiment} />
          )}
        </div>
      </div>
    </div>
  );
}
