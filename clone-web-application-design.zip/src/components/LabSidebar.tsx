import { Package } from "lucide-react";
import { describeModule } from "../lib/modules";
import { cn } from "../utils/cn";

interface LabSidebarProps {
  /** Python modules used by the open tab. */
  modules: string[];
  /** Where the modules come from, e.g. "EXP-01.A.1". */
  scope: string;
  className?: string;
}

/** Left column: the Python modules used by the open tab. */
export function LabSidebar({ modules, scope, className }: LabSidebarProps) {
  return (
    <aside className={cn("space-y-6", className)}>
      <section className="rounded-2xl border border-slate-200/80 bg-white/90 p-5 shadow-sm backdrop-blur-sm">
        <div className="mb-4 flex items-center justify-between gap-2">
          <h2 className="flex items-center gap-2 text-sm font-semibold text-slate-900">
            <Package className="h-4 w-4 text-purple-600" />
            Python modules
          </h2>
          <span className="rounded-full bg-purple-50 px-2 py-0.5 font-mono text-[11px] font-semibold text-purple-700">
            {scope}
          </span>
        </div>

        {modules.length > 0 ? (
          <ul className="space-y-2">
            {modules.map((name) => (
              <li
                key={name}
                className="rounded-xl border border-slate-100 bg-slate-50/70 px-3 py-2"
              >
                <p className="font-mono text-sm font-semibold text-purple-900">{name}</p>
                <p className="text-xs text-slate-500">{describeModule(name)}</p>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-slate-500">
            No modules yet. Add an import such as <code className="font-mono text-xs">import pandas</code>{" "}
            in the code.
          </p>
        )}
      </section>
    </aside>
  );
}
