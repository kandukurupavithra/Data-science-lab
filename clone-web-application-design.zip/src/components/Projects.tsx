import { useState, type FormEvent } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import {
  PROJECT_STATUSES,
  addProject,
  removeProject,
  updateProject,
  updateProjectStatus,
  useProjects,
  type Project,
  type ProjectStatus,
} from "../lib/projects";
import { cn } from "../utils/cn";
import { INPUT_CLASS } from "./form";
import { PageHeading } from "./ui";

const STATUS_STYLES: Record<ProjectStatus, string> = {
  Idea: "bg-amber-50 text-amber-700 ring-amber-200",
  "In progress": "bg-sky-50 text-sky-700 ring-sky-200",
  Completed: "bg-emerald-50 text-emerald-700 ring-emerald-200",
};

export function Projects() {
  const projects = useProjects();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState<ProjectStatus>("Idea");

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (!title.trim()) return;
    addProject(title.trim(), description.trim(), status);
    setTitle("");
    setDescription("");
    setStatus("Idea");
  }

  return (
    <div className="space-y-8">
      <PageHeading
        title="Projects"
        subtitle="Organize your data science projects and ideas."
        action={
          <span className="rounded-full bg-brand-100 px-3.5 py-1.5 text-sm font-bold text-brand-700">
            {projects.length} {projects.length === 1 ? "project" : "projects"}
          </span>
        }
      />

      <form
        onSubmit={handleSubmit}
        className="grid gap-3 rounded-3xl border border-brand-100 bg-white/95 p-5 shadow-sm backdrop-blur-sm lg:grid-cols-[1fr_1.6fr_auto_auto]"
      >
        <input
          value={title}
          onChange={(event) => setTitle(event.target.value)}
          placeholder="Project title"
          aria-label="Project title"
          className={INPUT_CLASS}
        />
        <input
          value={description}
          onChange={(event) => setDescription(event.target.value)}
          placeholder="What is it about? (optional)"
          aria-label="Project description"
          className={INPUT_CLASS}
        />
        <select
          value={status}
          onChange={(event) => setStatus(event.target.value as ProjectStatus)}
          aria-label="Project status"
          className={INPUT_CLASS}
        >
          {PROJECT_STATUSES.map((item) => (
            <option key={item} value={item}>
              {item}
            </option>
          ))}
        </select>
        <button
          type="submit"
          disabled={!title.trim()}
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-brand-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <Plus className="h-4 w-4" />
          Add project
        </button>
      </form>

      {projects.length > 0 ? (
        <div className="grid items-start gap-6 md:grid-cols-2 xl:grid-cols-3">
          {projects.map((project) => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      ) : (
        <div className="rounded-3xl border border-dashed border-brand-200 bg-white/70 px-6 py-14 text-center">
          <span className="text-5xl" aria-hidden="true">
            💡
          </span>
          <p className="mt-4 text-lg font-bold text-ink">No projects yet</p>
          <p className="mx-auto mt-1 max-w-md text-muted">
            Add your first project or idea above and it will show up here and on the home page.
          </p>
        </div>
      )}
    </div>
  );
}

function ProjectCard({ project }: { project: Project }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState({
    title: project.title,
    description: project.description,
    status: project.status,
  });

  function startEdit() {
    setDraft({ title: project.title, description: project.description, status: project.status });
    setEditing(true);
  }

  function save(event: FormEvent) {
    event.preventDefault();
    if (!draft.title.trim()) return;
    updateProject(project.id, {
      title: draft.title.trim(),
      description: draft.description.trim(),
      status: draft.status,
    });
    setEditing(false);
  }

  function remove() {
    if (window.confirm(`Delete the project "${project.title}"?`)) removeProject(project.id);
  }

  if (editing) {
    return (
      <form
        onSubmit={save}
        className="space-y-3 rounded-3xl border border-brand-300 bg-white/95 p-6 shadow-sm backdrop-blur-sm"
      >
        <input
          autoFocus
          value={draft.title}
          onChange={(event) => setDraft((current) => ({ ...current, title: event.target.value }))}
          aria-label="Project title"
          className={INPUT_CLASS}
        />
        <textarea
          rows={3}
          value={draft.description}
          onChange={(event) =>
            setDraft((current) => ({ ...current, description: event.target.value }))
          }
          placeholder="What is it about?"
          aria-label="Project description"
          className={INPUT_CLASS}
        />
        <select
          value={draft.status}
          onChange={(event) =>
            setDraft((current) => ({ ...current, status: event.target.value as ProjectStatus }))
          }
          aria-label="Project status"
          className={INPUT_CLASS}
        >
          {PROJECT_STATUSES.map((item) => (
            <option key={item} value={item}>
              {item}
            </option>
          ))}
        </select>
        <div className="flex gap-2">
          <button
            type="submit"
            disabled={!draft.title.trim()}
            className="rounded-xl bg-brand-600 px-5 py-2 text-sm font-bold text-white transition hover:bg-brand-700 disabled:cursor-not-allowed disabled:opacity-50"
          >
            Save
          </button>
          <button
            type="button"
            onClick={() => setEditing(false)}
            className="rounded-xl border border-brand-100 bg-white px-4 py-2 text-sm font-semibold text-muted transition hover:bg-brand-50"
          >
            Cancel
          </button>
        </div>
      </form>
    );
  }

  return (
    <article className="flex flex-col rounded-3xl border border-brand-100 bg-white/95 p-6 shadow-sm backdrop-blur-sm">
      <div className="flex items-start justify-between gap-3">
        <h3 className="text-lg font-bold leading-snug text-ink">{project.title}</h3>
        <div className="-mr-2 -mt-1 flex shrink-0">
          <button
            type="button"
            onClick={startEdit}
            aria-label={`Edit ${project.title}`}
            title="Edit project"
            className="rounded-full p-2 text-muted transition hover:bg-brand-50 hover:text-brand-600"
          >
            <Pencil className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={remove}
            aria-label={`Delete ${project.title}`}
            title="Delete project"
            className="rounded-full p-2 text-rose-300 transition hover:bg-rose-50 hover:text-rose-500"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>
      <p className="mt-2 flex-1 text-sm leading-relaxed text-muted">
        {project.description || "No description yet."}
      </p>
      <div className="mt-5 flex items-center justify-between gap-3 border-t border-brand-50 pt-4">
        <select
          value={project.status}
          onChange={(event) => updateProjectStatus(project.id, event.target.value as ProjectStatus)}
          aria-label={`Status of ${project.title}`}
          className={cn(
            "cursor-pointer rounded-full px-3 py-1 text-xs font-bold ring-1 ring-inset outline-none",
            STATUS_STYLES[project.status],
          )}
        >
          {PROJECT_STATUSES.map((item) => (
            <option key={item} value={item}>
              {item}
            </option>
          ))}
        </select>
        <time className="text-xs text-muted">
          {new Date(project.createdAt).toLocaleDateString(undefined, {
            day: "numeric",
            month: "short",
            year: "numeric",
          })}
        </time>
      </div>
    </article>
  );
}
