import { useState } from "react";
import { Pencil, Trash2 } from "lucide-react";
import {
  addModule,
  describeModuleContents,
  removeModule,
  updateModule,
  useLearningModules,
  type LearningModule,
} from "../lib/learning";
import { moduleHref } from "../lib/router";
import { ModuleForm } from "./LearningForms";

type FormMode = null | { mode: "add" } | { mode: "edit"; id: string };

const plural = (count: number, word: string) => `${count} ${word}${count === 1 ? "" : "s"}`;

export function Modules() {
  const modules = useLearningModules();
  const [form, setForm] = useState<FormMode>(null);

  const editing =
    form?.mode === "edit" ? (modules.find((item) => item.id === form.id) ?? null) : null;
  const showForm = form?.mode === "add" || editing !== null;

  function startEdit(item: LearningModule) {
    setForm({ mode: "edit", id: item.id });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function handleDelete(item: LearningModule) {
    const contents = describeModuleContents(item);
    const confirmed = window.confirm(
      `Delete the module "${item.title}"${contents ? ` with its ${contents}` : ""}?\n\nThis cannot be undone.`,
    );
    if (confirmed) removeModule(item.id);
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-ink sm:text-4xl">Learning Modules</h1>
        <p className="mt-3 text-base text-muted sm:text-lg">
          Create your own modules and add topics inside each module.
        </p>
        <button
          type="button"
          onClick={() => setForm({ mode: "add" })}
          className="mt-6 rounded-xl bg-brand-600 px-6 py-3.5 text-base font-bold text-white shadow-md shadow-brand-200 transition hover:bg-brand-700"
        >
          + Add Module
        </button>
      </div>

      {showForm && form && (
        <ModuleForm
          key={form.mode === "edit" ? form.id : "add"}
          initial={
            editing
              ? { title: editing.title, description: editing.description }
              : { title: "", description: "" }
          }
          heading={editing ? "Edit module" : "New module"}
          submitLabel={editing ? "Save changes" : "Add module"}
          onSubmit={(values) => {
            if (form.mode === "edit") {
              updateModule(form.id, values);
              setForm(null);
            } else {
              const id = addModule(values.title, values.description);
              setForm(null);
              // Open the new module so topics can be added straight away.
              window.location.hash = moduleHref(id);
            }
          }}
          onCancel={() => setForm(null)}
        />
      )}

      {modules.length === 0 ? (
        !showForm && (
          <p className="max-w-xs text-base leading-relaxed text-muted">
            No modules yet. Click Add Module to begin.
          </p>
        )
      ) : (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {modules.map((item) => (
            <ModuleCard
              key={item.id}
              item={item}
              onEdit={() => startEdit(item)}
              onDelete={() => handleDelete(item)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

interface ModuleCardProps {
  item: LearningModule;
  onEdit: () => void;
  onDelete: () => void;
}

function ModuleCard({ item, onEdit, onDelete }: ModuleCardProps) {
  const total = item.topics.length;
  const done = item.topics.filter((topic) => topic.done).length;
  const percent = total === 0 ? 0 : Math.round((done / total) * 100);

  return (
    <article className="group relative flex flex-col rounded-3xl border border-brand-100 bg-white/95 p-7 shadow-sm backdrop-blur-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-brand-100">
      <div className="flex items-start justify-between gap-3">
        <span className="text-4xl" aria-hidden="true">
          📚
        </span>
        <div className="relative z-10 -mr-2 -mt-1 flex shrink-0">
          <button
            type="button"
            onClick={onEdit}
            aria-label={`Edit ${item.title}`}
            title="Edit module"
            className="rounded-full p-2 text-muted transition hover:bg-brand-50 hover:text-brand-600"
          >
            <Pencil className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={onDelete}
            aria-label={`Delete ${item.title}`}
            title="Delete module"
            className="rounded-full p-2 text-rose-300 transition hover:bg-rose-50 hover:text-rose-500"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>

      <h3 className="mt-5 text-xl font-bold leading-snug text-ink">
        {/* The link stretches over the whole card; the edit and delete buttons sit above it. */}
        <a
          href={moduleHref(item.id)}
          className="outline-none after:absolute after:inset-0 focus-visible:after:rounded-3xl focus-visible:after:ring-4 focus-visible:after:ring-brand-300"
        >
          {item.title}
        </a>
      </h3>
      <p className="mt-2 line-clamp-3 flex-1 text-base leading-relaxed text-muted">
        {item.description || "No description yet."}
      </p>

      <div className="mt-6 space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="font-semibold text-ink">
            {plural(total, "topic")} • {plural(item.files.length, "file")}
          </span>
          {total > 0 && <span className="text-muted">{done} done</span>}
        </div>
        <div
          role="progressbar"
          aria-label="Topics completed"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={percent}
          className="h-2 overflow-hidden rounded-full bg-brand-100"
        >
          <div
            className="h-full rounded-full bg-brand-600 transition-all"
            style={{ width: `${percent}%` }}
          />
        </div>
      </div>

      <span className="mt-6 text-base font-bold text-brand-600 transition group-hover:translate-x-1">
        Open module →
      </span>
    </article>
  );
}
