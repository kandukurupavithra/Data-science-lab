import { useState, type FormEvent } from "react";

interface AddSubFormProps {
  onSubmit: (title: string, summary: string) => void;
  onCancel: () => void;
}

export function AddSubForm({ onSubmit, onCancel }: AddSubFormProps) {
  const [title, setTitle] = useState("");
  const [summary, setSummary] = useState("");

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (!title.trim()) return;
    onSubmit(title.trim(), summary.trim());
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="grid gap-3 rounded-2xl border border-purple-100 bg-white/90 p-4 shadow-sm backdrop-blur sm:grid-cols-[1fr_1.4fr_auto]"
    >
      <input
        autoFocus
        value={title}
        onChange={(event) => setTitle(event.target.value)}
        placeholder="Sub-experiment title"
        aria-label="Sub-experiment title"
        className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none transition placeholder:text-slate-400 focus:border-purple-300 focus:ring-4 focus:ring-purple-100"
      />
      <input
        value={summary}
        onChange={(event) => setSummary(event.target.value)}
        placeholder="Short summary (optional)"
        aria-label="Sub-experiment summary"
        className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none transition placeholder:text-slate-400 focus:border-purple-300 focus:ring-4 focus:ring-purple-100"
      />
      <div className="flex gap-2">
        <button
          type="submit"
          disabled={!title.trim()}
          className="rounded-xl bg-purple-700 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-purple-600 disabled:cursor-not-allowed disabled:opacity-50"
        >
          Add
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-medium text-slate-600 transition hover:bg-slate-50"
        >
          Cancel
        </button>
      </div>
    </form>
  );
}
