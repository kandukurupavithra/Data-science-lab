import { useEffect, useRef } from "react";
import { Plus, Trash2, Undo2 } from "lucide-react";
import type { Experiment, SubExperiment } from "../data/types";
import { experimentHref } from "../lib/router";
import { cn } from "../utils/cn";

interface ExperimentTabsProps {
  experiment: Experiment;
  subs: SubExperiment[];
  /** Number of the open sub-experiment, or null when the main experiment tab is open. */
  activeSub: string | null;
  addOpen: boolean;
  removedCount: number;
  onToggleAdd: () => void;
  onDelete: (sub: SubExperiment) => void;
  onRestore: () => void;
}

const ACTIVE_TAB =
  "bg-gradient-to-b from-purple-600 to-purple-800 text-white shadow-lg shadow-purple-300/60";
const IDLE_TAB =
  "border border-purple-100 bg-white text-purple-900 shadow-sm hover:border-purple-300 hover:shadow-md";

export function ExperimentTabs({
  experiment,
  subs,
  activeSub,
  addOpen,
  removedCount,
  onToggleAdd,
  onDelete,
  onRestore,
}: ExperimentTabsProps) {
  const activeRef = useRef<HTMLDivElement>(null);

  // Keep the open tab visible when the bar scrolls sideways.
  useEffect(() => {
    activeRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "nearest" });
  }, [activeSub]);

  return (
    <nav aria-label="Experiment tabs" className="thin-scroll -mx-1 flex items-center gap-3 overflow-x-auto px-1 py-2">
      <a
        href={experimentHref(experiment.id)}
        aria-current={activeSub === null ? "page" : undefined}
        className={cn(
          "shrink-0 whitespace-nowrap rounded-full px-5 py-2.5 text-sm font-bold transition",
          activeSub === null ? ACTIVE_TAB : IDLE_TAB,
        )}
      >
        Main Experiment ({experiment.expNumber})
      </a>

      {subs.map((sub) => {
        const active = sub.subExpNumber === activeSub;
        const label = `${sub.subExpNumber}: ${sub.title}`;
        return (
          <div
            key={sub.subExpNumber}
            ref={active ? activeRef : undefined}
            className={cn("flex shrink-0 items-center rounded-full transition", active ? ACTIVE_TAB : IDLE_TAB)}
          >
            <a
              href={experimentHref(experiment.id, sub.subExpNumber)}
              aria-current={active ? "page" : undefined}
              title={label}
              className="max-w-[19rem] truncate py-2.5 pl-4 pr-2 text-sm font-bold"
            >
              {label}
            </a>
            <button
              type="button"
              onClick={() => onDelete(sub)}
              aria-label={`Remove ${sub.subExpNumber}`}
              title="Remove sub-experiment"
              className={cn(
                "mr-1.5 rounded-full p-2 transition",
                active
                  ? "text-purple-200 hover:bg-white/15 hover:text-white"
                  : "text-rose-300 hover:bg-rose-50 hover:text-rose-500",
              )}
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        );
      })}

      <button
        type="button"
        onClick={onToggleAdd}
        aria-expanded={addOpen}
        className="inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border border-dashed border-purple-300 bg-white/70 px-4 py-2.5 text-sm font-semibold text-purple-800 transition hover:bg-white"
      >
        <Plus className="h-4 w-4" />
        Add
      </button>

      {removedCount > 0 && (
        <button
          type="button"
          onClick={onRestore}
          className="inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-3 py-2.5 text-sm font-medium text-slate-600 transition hover:text-purple-700"
        >
          <Undo2 className="h-4 w-4" />
          Restore removed ({removedCount})
        </button>
      )}
    </nav>
  );
}
