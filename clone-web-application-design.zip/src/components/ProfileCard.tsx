import { useRef, useState, type ChangeEvent } from "react";
import {
  Camera,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  GraduationCap,
  Pencil,
  ShieldCheck,
  Sparkles,
  Upload,
} from "lucide-react";
import { readPhotoFile } from "../lib/photo";
import { getInitials, updateProfile, useProfile } from "../lib/profile";

function GitHubMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" className={className}>
      <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12" />
    </svg>
  );
}

function Detail({
  label,
  value,
  align = "left",
}: {
  label: string;
  value: string;
  align?: "left" | "right";
}) {
  return (
    <div className={align === "right" ? "text-right" : undefined}>
      <p className="text-[11px] font-bold uppercase tracking-wide text-purple-500">{label}</p>
      <p className="mt-0.5 font-semibold text-slate-800">{value}</p>
    </div>
  );
}

/** The student's "Data Science Lab Pass": photo, name, ID and lab details. */
export function ProfileCard({ onEdit }: { onEdit: () => void }) {
  const profile = useProfile();
  const fileInput = useRef<HTMLInputElement>(null);
  const [open, setOpen] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleFile(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = ""; // lets the same picture be chosen again later
    if (!file) return;

    setBusy(true);
    setError(null);
    try {
      updateProfile({ photo: await readPhotoFile(file) });
    } catch (problem) {
      setError(problem instanceof Error ? problem.message : "That photo could not be used.");
    } finally {
      setBusy(false);
    }
  }

  const chooseFile = () => fileInput.current?.click();

  return (
    <article className="overflow-hidden rounded-3xl border border-purple-300 bg-white shadow-xl shadow-purple-200/60">
      <div className="bg-purple-950 px-5 pb-3 pt-2.5">
        <div
          aria-hidden="true"
          className="mx-auto h-2 w-14 rounded-full border border-purple-400/50 bg-purple-800"
        />
        <button
          type="button"
          onClick={() => setOpen((value) => !value)}
          aria-expanded={open}
          className="mt-2.5 flex w-full items-center justify-between gap-3 text-left text-xs font-bold uppercase tracking-wider text-purple-200"
        >
          <span className="inline-flex min-w-0 items-center gap-2">
            <GraduationCap className="h-4 w-4 shrink-0" />
            <span className="truncate">{profile.university}</span>
          </span>
          {open ? <ChevronUp className="h-4 w-4 shrink-0" /> : <ChevronDown className="h-4 w-4 shrink-0" />}
        </button>
      </div>

      <div className="flex items-center justify-center gap-2 bg-gradient-to-r from-purple-700 via-purple-600 to-purple-700 py-2.5 text-sm font-extrabold uppercase tracking-wide text-white">
        <Sparkles className="h-4 w-4" />
        Data Science Lab Pass
      </div>

      {open && (
        <div className="bg-gradient-to-b from-white to-purple-50/70 p-5">
          <input
            ref={fileInput}
            type="file"
            accept="image/*"
            onChange={handleFile}
            className="hidden"
            aria-label="Upload profile photo"
          />

          <div className="flex gap-5">
            <div className="relative h-40 w-32 shrink-0">
              <div className="h-full w-full rounded-2xl border-2 border-purple-700 bg-white p-1.5 shadow-md">
                <div className="flex h-full w-full items-center justify-center overflow-hidden rounded-lg bg-purple-100">
                  {profile.photo ? (
                    <img src={profile.photo} alt={`Photo of ${profile.name}`} className="h-full w-full object-cover" />
                  ) : (
                    <span className="text-4xl font-bold text-purple-700">{getInitials(profile.name)}</span>
                  )}
                </div>
              </div>
              <button
                type="button"
                onClick={chooseFile}
                disabled={busy}
                aria-label="Change photo"
                title="Change photo"
                className="absolute -bottom-2 -right-2 flex h-9 w-9 items-center justify-center rounded-full border-2 border-white bg-purple-700 text-white shadow-md transition hover:bg-purple-600 disabled:cursor-wait disabled:opacity-70"
              >
                <Camera className="h-4 w-4" />
              </button>
            </div>

            <div className="min-w-0 flex-1 pt-1">
              <h2 className="break-words font-serif text-2xl font-bold leading-tight text-purple-950">
                {profile.name}
              </h2>
              <p className="mt-2.5 inline-block max-w-full truncate rounded-md border border-fuchsia-200 bg-fuchsia-50 px-2.5 py-1 font-mono text-xs font-bold text-purple-800">
                ID: {profile.studentId}
              </p>
              <p className="mt-2.5 text-sm text-slate-500">
                {profile.section} • Class of {profile.passingYear}
              </p>
              <p className="mt-1 text-sm font-semibold text-slate-800">{profile.semester}</p>
            </div>
          </div>

          <div className="mt-6 space-y-3.5 rounded-2xl border border-purple-100 bg-white/80 p-4">
            <Detail label="Subject & Lab" value={profile.subject} />
            <div className="flex items-start justify-between gap-4 border-t border-purple-50 pt-3.5">
              <Detail label="Professor In-Charge" value={profile.professor} />
              <Detail label="Passing Year" value={profile.passingYear} align="right" />
            </div>
          </div>

          <div className="mt-5 flex gap-3">
            <button
              type="button"
              onClick={chooseFile}
              disabled={busy}
              className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-purple-700 px-4 py-3 text-sm font-bold text-white shadow-md shadow-purple-300/50 transition hover:bg-purple-600 disabled:cursor-wait disabled:opacity-70"
            >
              <Upload className="h-4 w-4" />
              {busy ? "Processing…" : profile.photo ? "Change Photo" : "Upload Photo"}
            </button>
            <button
              type="button"
              onClick={onEdit}
              className="inline-flex items-center justify-center gap-2 rounded-xl border border-purple-300 bg-white px-4 py-3 text-sm font-bold text-purple-800 transition hover:bg-purple-50"
            >
              <Pencil className="h-4 w-4" />
              Edit ID
            </button>
          </div>

          {error && (
            <p role="alert" className="mt-3 text-sm font-medium text-rose-600">
              {error}
            </p>
          )}

          <div className="mt-5 flex items-center justify-between gap-3 border-t border-purple-100 pt-4">
            {profile.github ? (
              <a
                href={profile.github}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 text-sm font-semibold text-purple-900 transition hover:text-purple-600"
              >
                <GitHubMark className="h-4 w-4" />
                GitHub
                <ExternalLink className="h-3 w-3 opacity-70" />
              </a>
            ) : (
              <span />
            )}
            <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-300 bg-amber-50 px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-amber-900">
              <ShieldCheck className="h-3.5 w-3.5" />
              Verified Lab Pass
            </span>
          </div>
        </div>
      )}
    </article>
  );
}
