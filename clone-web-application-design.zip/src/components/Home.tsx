import { tools } from "../data/tools";
import { useExperiments } from "../lib/labStore";
import { useLearningModules } from "../lib/learning";
import { useProjects } from "../lib/projects";

interface Shortcut {
  emoji: string;
  title: string;
  text: string;
  href: string;
}

const GET_STARTED: Shortcut[] = [
  {
    emoji: "📊",
    title: "Data Visualization",
    text: "Create charts and understand patterns in data.",
    href: "#/tools",
  },
  {
    emoji: "🐍",
    title: "Python Practice",
    text: "Learn data analysis using Python libraries.",
    href: "#/experiments",
  },
  {
    emoji: "🚀",
    title: "Build a Project",
    text: "Turn your ideas into practical applications.",
    href: "#/projects",
  },
];

export function Home() {
  const projects = useProjects();
  const experiments = useExperiments();
  const learningModules = useLearningModules();

  const overview = [
    {
      emoji: "🧪",
      count: experiments.length,
      title: "Experiments",
      text: "Practice Python, pandas, data processing, and analysis.",
      linkLabel: "View experiments →",
      href: "#/experiments",
    },
    {
      emoji: "💡",
      count: projects.length,
      title: "Projects",
      text: "Organize your data science projects and ideas.",
      linkLabel: "View projects →",
      href: "#/projects",
    },
    {
      emoji: "📚",
      count: learningModules.length,
      title: "Modules",
      text: "Create your own modules and add topics inside each module.",
      linkLabel: "View modules →",
      href: "#/modules",
    },
    {
      emoji: "🛠️",
      count: tools.length,
      title: "Learning Tools",
      text: "Access useful platforms for coding and visualization.",
      linkLabel: "Explore tools →",
      href: "#/tools",
    },
  ];

  return (
    <div className="space-y-10">
      <section className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-brand-600 via-brand-500 to-brand-400 px-7 py-10 text-white shadow-xl shadow-brand-200/70 sm:px-10 sm:py-12">
        <div aria-hidden="true" className="absolute -right-16 -top-20 h-64 w-64 rounded-full bg-white/10" />
        <div aria-hidden="true" className="absolute -bottom-24 right-24 h-56 w-56 rounded-full bg-white/10" />
        <div className="relative">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Welcome to Your Data Science Lab <span aria-hidden="true">👋</span>
          </h2>
          <p className="mt-4 max-w-xl text-base leading-relaxed text-white/90 sm:text-lg">
            Explore experiments, build projects, discover useful tools, and organize your data science
            learning in one place.
          </p>
          <a
            href="#/experiments"
            className="mt-7 inline-flex items-center rounded-xl bg-white px-6 py-3.5 text-base font-bold text-brand-600 shadow-sm transition hover:-translate-y-0.5 hover:shadow-lg"
          >
            Explore Experiments →
          </a>
        </div>
      </section>

      <section className="grid gap-6 sm:grid-cols-2 xl:grid-cols-4">
        {overview.map((item) => (
          <a
            key={item.title}
            href={item.href}
            className="group flex flex-col rounded-3xl border border-brand-100 bg-white/95 p-7 shadow-sm backdrop-blur-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-brand-100"
          >
            <span className="text-4xl" aria-hidden="true">
              {item.emoji}
            </span>
            <p className="mt-6 text-4xl font-bold text-brand-600">{item.count}</p>
            <h3 className="mt-1 text-xl font-bold text-ink">{item.title}</h3>
            <p className="mt-3 flex-1 text-base leading-relaxed text-muted">{item.text}</p>
            <span className="mt-6 text-base font-bold text-brand-600 transition group-hover:translate-x-1">
              {item.linkLabel}
            </span>
          </a>
        ))}
      </section>

      <section className="space-y-5">
        <h2 className="text-2xl font-bold tracking-tight text-ink">Get Started</h2>
        <div className="grid gap-6 md:grid-cols-3">
          {GET_STARTED.map((item) => (
            <a
              key={item.title}
              href={item.href}
              className="rounded-3xl border border-brand-100 bg-white/95 p-7 shadow-sm backdrop-blur-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-brand-100"
            >
              <span className="text-4xl" aria-hidden="true">
                {item.emoji}
              </span>
              <h3 className="mt-6 text-xl font-bold text-ink">{item.title}</h3>
              <p className="mt-3 text-base leading-relaxed text-muted">{item.text}</p>
            </a>
          ))}
        </div>
      </section>
    </div>
  );
}
