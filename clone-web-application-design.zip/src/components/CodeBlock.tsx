import { useRef, useState, type KeyboardEvent, type ReactNode } from "react";
import { Check, Copy } from "lucide-react";
import { cn } from "../utils/cn";

type Variant = "code" | "output";

interface CodeBlockProps {
  title: string;
  badge?: string;
  text: string;
  variant: Variant;
  emptyMessage: string;
  /** Extra buttons (edit, delete, …) shown in the panel header next to Copy. */
  actions?: ReactNode;
}

/** Small text button for the dark panel header. */
export function PanelButton({
  icon,
  label,
  onClick,
  danger,
}: {
  icon: ReactNode;
  label: string;
  onClick: () => void;
  danger?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium transition hover:bg-white/5",
        danger ? "text-rose-300 hover:text-rose-200" : "text-slate-300 hover:text-white",
      )}
    >
      {icon}
      {label}
    </button>
  );
}

/** Read-only dark panel for a program or its output, with a copy button. */
export function CodeBlock({ title, badge, text, variant, emptyMessage, actions }: CodeBlockProps) {
  const [copied, setCopied] = useState(false);
  const body = text.replace(/\s+$/, "");
  const hasText = body.length > 0;

  async function copy() {
    try {
      await navigator.clipboard.writeText(body);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
    } catch {
      setCopied(false);
    }
  }

  return (
    <section className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-950 shadow-lg shadow-purple-100">
      <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-1 border-b border-white/10 bg-slate-900 px-4 py-2">
        <div className="flex min-w-0 items-center gap-2 text-xs font-medium text-slate-300">
          <span
            className={cn(
              "h-2 w-2 shrink-0 rounded-full",
              variant === "code" ? "bg-violet-400" : "bg-emerald-400",
            )}
          />
          <span className="truncate font-semibold">{title}</span>
          {badge && (
            <span className="shrink-0 rounded-md bg-violet-400/15 px-1.5 py-0.5 text-[10px] font-semibold text-violet-200">
              {badge}
            </span>
          )}
        </div>
        <div className="flex items-center">
          {actions}
          <button
            type="button"
            onClick={copy}
            disabled={!hasText}
            className="inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-300 transition hover:bg-white/5 hover:text-white disabled:cursor-not-allowed disabled:opacity-40"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
            {copied ? "Copied" : "Copy"}
          </button>
        </div>
      </div>

      {hasText ? (
        <div className="flex max-h-[34rem] overflow-auto font-mono text-[13px] leading-6">
          {variant === "code" && (
            <div
              aria-hidden="true"
              className="sticky left-0 select-none bg-slate-900 py-4 pl-4 pr-3 text-right text-slate-600"
            >
              {body.split("\n").map((_, index) => (
                <div key={index}>{index + 1}</div>
              ))}
            </div>
          )}
          <pre
            className={cn(
              "flex-1 whitespace-pre p-4",
              variant === "code" ? "text-slate-100" : "text-emerald-200",
            )}
          >
            {body}
          </pre>
        </div>
      ) : (
        <p className="p-5 text-sm text-slate-500">{emptyMessage}</p>
      )}
    </section>
  );
}

interface CodeInputProps {
  value: string;
  onChange: (value: string) => void;
  label: string;
  variant: Variant;
  placeholder?: string;
  minRows?: number;
}

/** Dark textarea for typing or pasting code or output. In code boxes Tab indents; Esc then Tab leaves. */
export function CodeInput({ value, onChange, label, variant, placeholder, minRows = 8 }: CodeInputProps) {
  const ref = useRef<HTMLTextAreaElement>(null);
  const releaseTab = useRef(false);

  function handleKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Escape") {
      releaseTab.current = true;
      return;
    }
    if (variant === "code" && event.key === "Tab" && !event.shiftKey && !releaseTab.current) {
      event.preventDefault();
      const { selectionStart, selectionEnd } = event.currentTarget;
      onChange(`${value.slice(0, selectionStart)}    ${value.slice(selectionEnd)}`);
      requestAnimationFrame(() => {
        if (ref.current) ref.current.selectionStart = ref.current.selectionEnd = selectionStart + 4;
      });
      return;
    }
    if (event.key !== "Tab") releaseTab.current = false;
  }

  return (
    <textarea
      ref={ref}
      value={value}
      onChange={(event) => onChange(event.target.value)}
      onKeyDown={handleKeyDown}
      onBlur={() => {
        releaseTab.current = false;
      }}
      rows={Math.min(Math.max(value.split("\n").length + 1, minRows), 24)}
      wrap="off"
      spellCheck={false}
      autoCapitalize="off"
      autoCorrect="off"
      aria-label={label}
      placeholder={placeholder}
      className={cn(
        "block w-full resize-y overflow-auto whitespace-pre rounded-xl border border-slate-800 bg-slate-950 p-4 font-mono text-[13px] leading-6 outline-none transition placeholder:text-slate-600 focus:ring-4 focus:ring-brand-200",
        variant === "code" ? "text-slate-100" : "text-emerald-200",
      )}
    />
  );
}
