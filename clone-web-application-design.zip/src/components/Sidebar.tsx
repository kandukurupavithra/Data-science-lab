import {
  FlaskConical,
  FolderKanban,
  House,
  Layers,
  User,
  Wrench,
  type LucideIcon,
} from "lucide-react";
import { pageHref, type PageName } from "../lib/router";
import { cn } from "../utils/cn";

interface NavItem {
  key: PageName;
  label: string;
  icon: LucideIcon;
}

export const NAV_ITEMS: NavItem[] = [
  { key: "home", label: "Home", icon: House },
  { key: "experiments", label: "Experiments", icon: FlaskConical },
  { key: "projects", label: "Projects", icon: FolderKanban },
  { key: "modules", label: "Modules", icon: Layers },
  { key: "tools", label: "Tools", icon: Wrench },
  { key: "profile", label: "Profile", icon: User },
];

function Logo() {
  return (
    <a href={pageHref("home")} className="inline-block text-2xl font-extrabold tracking-tight text-ink">
      <span className="text-brand-600">DS</span> LAB
    </a>
  );
}

/** Left navigation for large screens. */
export function Sidebar({ active }: { active: PageName }) {
  return (
    <aside className="sticky top-0 hidden h-screen w-72 shrink-0 self-start flex-col border-r border-brand-100 bg-white/90 px-6 py-8 backdrop-blur-md lg:flex">
      <Logo />
      <nav aria-label="Main" className="mt-10 flex flex-col gap-2">
        {NAV_ITEMS.map(({ key, label, icon: Icon }) => {
          const isActive = key === active;
          return (
            <a
              key={key}
              href={pageHref(key)}
              aria-current={isActive ? "page" : undefined}
              className={cn(
                "flex items-center gap-4 rounded-2xl px-5 py-3.5 text-[15px] transition-colors",
                isActive
                  ? "bg-brand-100 font-bold text-brand-600"
                  : "font-medium text-muted hover:bg-brand-50 hover:text-brand-600",
              )}
            >
              <Icon className="h-[18px] w-[18px]" />
              {label}
            </a>
          );
        })}
      </nav>
    </aside>
  );
}

/** Logo and a scrolling pill menu for screens without the sidebar. */
export function MobileNav({ active }: { active: PageName }) {
  return (
    <div className="border-b border-brand-100 bg-white/90 px-4 pt-4 backdrop-blur-md lg:hidden">
      <Logo />
      <nav aria-label="Main" className="thin-scroll -mx-1 mt-3 flex gap-2 overflow-x-auto px-1 pb-3">
        {NAV_ITEMS.map(({ key, label, icon: Icon }) => {
          const isActive = key === active;
          return (
            <a
              key={key}
              href={pageHref(key)}
              aria-current={isActive ? "page" : undefined}
              className={cn(
                "inline-flex shrink-0 items-center gap-2 rounded-full px-4 py-2 text-sm transition-colors",
                isActive
                  ? "bg-brand-100 font-bold text-brand-600"
                  : "bg-white font-medium text-muted ring-1 ring-brand-100 hover:text-brand-600",
              )}
            >
              <Icon className="h-4 w-4" />
              {label}
            </a>
          );
        })}
      </nav>
    </div>
  );
}
