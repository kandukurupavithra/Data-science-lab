import { useState, type FormEvent } from "react";
import { tools } from "../data/tools";
import { useExperiments } from "../lib/labStore";
import { useLearningModules } from "../lib/learning";
import { updateProfile, useProfile, type ProfileData } from "../lib/profile";
import { useProjects } from "../lib/projects";
import { Field, FormButtons, FormCard, INPUT_CLASS } from "./form";
import { ProfileCard } from "./ProfileCard";
import { PageHeading } from "./ui";

type IdFields = Omit<ProfileData, "photo">;

const FIELDS: Array<{
  key: keyof IdFields;
  label: string;
  placeholder?: string;
  wide?: boolean;
}> = [
  { key: "name", label: "Full name", wide: true },
  { key: "studentId", label: "Student ID" },
  { key: "university", label: "University" },
  { key: "section", label: "Section" },
  { key: "semester", label: "Semester" },
  { key: "subject", label: "Subject & lab" },
  { key: "professor", label: "Professor in-charge" },
  { key: "passingYear", label: "Passing year" },
  { key: "github", label: "GitHub link", placeholder: "https://github.com/your-name", wide: true },
];

export function Profile() {
  const profile = useProfile();
  const projects = useProjects();
  const experiments = useExperiments();
  const learningModules = useLearningModules();
  const [editing, setEditing] = useState(false);

  const completed = experiments.filter((experiment) => experiment.status === "Completed").length;

  const stats = [
    { label: "Experiments completed", value: `${completed}/${experiments.length}` },
    { label: "Projects", value: String(projects.length) },
    { label: "Learning modules", value: String(learningModules.length) },
    { label: "Learning tools", value: String(tools.length) },
  ];

  return (
    <div className="space-y-8">
      <PageHeading title="Profile" subtitle="Your Data Science Lab pass and details." />

      <div className="grid gap-8 lg:grid-cols-[minmax(0,26rem)_minmax(0,1fr)] lg:items-start">
        <ProfileCard onEdit={() => setEditing(true)} />

        <div className="space-y-6">
          {editing && (
            <IdForm
              initial={{
                name: profile.name,
                studentId: profile.studentId,
                university: profile.university,
                section: profile.section,
                semester: profile.semester,
                subject: profile.subject,
                professor: profile.professor,
                passingYear: profile.passingYear,
                github: profile.github,
              }}
              hasPhoto={profile.photo !== ""}
              onClose={() => setEditing(false)}
            />
          )}

          <section className="grid gap-4 sm:grid-cols-2">
            {stats.map((stat) => (
              <div
                key={stat.label}
                className="rounded-3xl border border-brand-100 bg-white/95 p-6 shadow-sm backdrop-blur-sm"
              >
                <p className="text-3xl font-bold text-brand-600">{stat.value}</p>
                <p className="mt-1 text-sm font-semibold text-muted">{stat.label}</p>
              </div>
            ))}
          </section>
        </div>
      </div>
    </div>
  );
}

interface IdFormProps {
  initial: IdFields;
  hasPhoto: boolean;
  onClose: () => void;
}

/** Edit ID: the details printed on the pass. */
function IdForm({ initial, hasPhoto, onClose }: IdFormProps) {
  const [draft, setDraft] = useState<IdFields>(initial);

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (!draft.name.trim()) return;
    updateProfile(draft);
    onClose();
  }

  return (
    <FormCard title="Edit ID" onSubmit={handleSubmit}>
      <div className="grid gap-4 sm:grid-cols-2">
        {FIELDS.map(({ key, label, placeholder, wide }) => (
          <Field key={key} label={label} className={wide ? "sm:col-span-2" : undefined}>
            <input
              autoFocus={key === "name"}
              value={draft[key]}
              placeholder={placeholder}
              onChange={(event) => setDraft((current) => ({ ...current, [key]: event.target.value }))}
              className={INPUT_CLASS}
            />
          </Field>
        ))}
      </div>

      {hasPhoto && (
        <button
          type="button"
          onClick={() => updateProfile({ photo: "" })}
          className="text-sm font-semibold text-rose-600 transition hover:text-rose-700"
        >
          Remove photo
        </button>
      )}

      <FormButtons submitLabel="Save changes" disabled={!draft.name.trim()} onCancel={onClose} />
    </FormCard>
  );
}
