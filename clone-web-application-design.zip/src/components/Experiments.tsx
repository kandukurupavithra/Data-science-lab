import { useMemo, useState } from "react";
import { Plus, Search, Undo2 } from "lucide-react";
import type { Experiment } from "../data/types";
import {
  addExperiment,
  deleteExperiment,
  editExperiment,
  restoreExperiments,
  useExperiments,
  useLabState,
} from "../lib/labStore";
import { experimentHref } from "../lib/router";
import { ExperimentCard } from "./ExperimentCard";
import { ExperimentForm } from "./ExperimentForm";
import { PageHeading } from "./ui";

const ALL_CATEGORIES = "all";

type FormMode = null | { mode: "add" } | { mode: "edit"; id: number };

export function Experiments() {
  const experiments = useExperiments();
  const lab = useLabState();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState(ALL_CATEGORIES);
  const [form, setForm] = useState<FormMode>(null);

  const categories = useMemo(
    () => Array.from(new Set(experiments.map((experiment) => experiment.category))),
    [experiments],
  );

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    return experiments.filter((experiment) => {
      if (category !== ALL_CATEGORIES && experiment.category !== category) return false;
      if (!term) return true;
      const haystack = [
        experiment.expNumber,
        experiment.title,
        experiment.category,
        experiment.subject,
        experiment.overview,
        experiment.pythonLibs,
        ...experiment.subExperiments.map((sub) => `${sub.subExpNumber} ${sub.title}`),
      ]
        .join(" ")
        .toLowerCase();
      return haystack.includes(term);
    });
  }, [experiments, query, category]);

  const editing = form?.mode === "edit" ? (experiments.find((item) => item.id === form.id) ?? null) : null;
  const showForm = form !== null && (form.mode === "add" || editing !== null);

  function clearFilters() {
    setQuery("");
    setCategory(ALL_CATEGORIES);
  }

  function startEdit(experiment: Experiment) {
    setForm({ mode: "edit", id: experiment.id });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function handleDelete(experiment: Experiment) {
    const isAdded = lab.addedExperiments.some((item) => item.id === experiment.id);
    const confirmed = window.confirm(
      `Delete ${experiment.expNumber}: ${experiment.title}?\n\nIts sub-experiments go with it. ${
        isAdded ? "This cannot be undone." : 'You can bring it back with "Restore deleted".'
      }`,
    );
    if (confirmed) deleteExperiment(experiment.id);
  }

  return (
    <div className="space-y-8">
      <PageHeading
        title="Experiments"
        subtitle="Practice Python, pandas, data processing, and analysis."
        action={
          <div className="flex flex-wrap gap-2">
            {lab.deletedExperiments.length > 0 && (
              <button
                type="button"
                onClick={restoreExperiments}
                className="inline-flex items-center gap-1.5 rounded-xl border border-brand-100 bg-white px-4 py-2.5 text-sm font-semibold text-muted shadow-sm transition hover:bg-brand-50 hover:text-brand-700"
              >
                <Undo2 className="h-4 w-4" />
                Restore deleted ({lab.deletedExperiments.length})
              </button>
            )}
            <button
              type="button"
              onClick={() => setForm({ mode: "add" })}
              className="inline-flex items-center gap-1.5 rounded-xl bg-brand-600 px-4 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-brand-700"
            >
              <Plus className="h-4 w-4" />
              Add experiment
            </button>
          </div>
        }
      />

      {showForm && form && (
        <ExperimentForm
          key={form.mode === "edit" ? form.id : "add"}
          initial={editing}
          categories={categories}
          heading={editing ? `Edit ${editing.expNumber}` : "New experiment"}
          submitLabel={editing ? "Save changes" : "Add experiment"}
          onSubmit={(fields) => {
            if (form.mode === "edit") {
              editExperiment(form.id, fields);
              setForm(null);
            } else {
              const id = addExperiment(fields);
              setForm(null);
              window.location.hash = experimentHref(id);
            }
          }}
          onCancel={() => setForm(null)}
        />
      )}

      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <p className="text-sm text-muted">
          Showing <strong className="font-bold text-ink">{filtered.length}</strong> of{" "}
          <strong className="font-bold text-ink">{experiments.length}</strong> experiments
        </p>

        <div className="flex flex-col gap-3 sm:flex-row">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
            <input
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search experiments…"
              aria-label="Search experiments"
              className="w-full rounded-xl border border-brand-100 bg-white py-2.5 pl-9 pr-4 text-sm text-ink shadow-sm outline-none transition placeholder:text-muted focus:border-brand-400 focus:ring-4 focus:ring-brand-100 sm:w-72"
            />
          </div>
          <select
            value={category}
            onChange={(event) => setCategory(event.target.value)}
            aria-label="Filter by category"
            className="rounded-xl border border-brand-100 bg-white px-3 py-2.5 text-sm text-ink shadow-sm outline-none focus:border-brand-400 focus:ring-4 focus:ring-brand-100"
          >
            <option value={ALL_CATEGORIES}>All categories</option>
            {categories.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </select>
        </div>
      </div>

      {filtered.length > 0 ? (
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((experiment) => (
            <ExperimentCard
              key={experiment.id}
              experiment={experiment}
              onEdit={() => startEdit(experiment)}
              onDelete={() => handleDelete(experiment)}
            />
          ))}
        </div>
      ) : (
        <div className="rounded-3xl border border-dashed border-brand-200 bg-white/70 p-10 text-center">
          <p className="font-semibold text-ink">
            {experiments.length === 0 ? "No experiments yet." : "No experiments match your filters."}
          </p>
          {experiments.length > 0 && (
            <button
              type="button"
              onClick={clearFilters}
              className="mt-3 text-sm font-bold text-brand-600 hover:text-brand-700"
            >
              Clear filters
            </button>
          )}
        </div>
      )}
    </div>
  );
}
