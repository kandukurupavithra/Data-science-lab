import { useRef, useState, type ChangeEvent } from "react";
import { Pencil, Trash2, Upload } from "lucide-react";
import { countLines, describeFile, readTextFile } from "../lib/files";
import {
  addFile,
  removeFile,
  updateFile,
  type LearningModule,
  type ModuleFile,
} from "../lib/learning";
import { CodeBlock, PanelButton } from "./CodeBlock";
import { FileForm } from "./LearningForms";

type FormMode = null | { mode: "add" } | { mode: "edit"; id: string };

/** The files of a learning module: add by typing, upload from the computer, edit the code, delete. */
export function ModuleFiles({ item }: { item: LearningModule }) {
  const files = item.files;
  const [form, setForm] = useState<FormMode>(null);
  const [busy, setBusy] = useState(false);
  const [problems, setProblems] = useState<string[]>([]);
  const picker = useRef<HTMLInputElement>(null);
  const anchor = useRef<HTMLDivElement>(null);

  const editing =
    form?.mode === "edit" ? (files.find((file) => file.id === form.id) ?? null) : null;
  const showForm = form?.mode === "add" || editing !== null;
  const takenNames = files
    .filter((file) => file.id !== editing?.id)
    .map((file) => file.name.toLowerCase());

  function openForm(next: Exclude<FormMode, null>) {
    setProblems([]);
    setForm(next);
    // Bring the form into view once it has been drawn.
    requestAnimationFrame(() =>
      anchor.current?.scrollIntoView({ behavior: "smooth", block: "start" }),
    );
  }

  async function handleUpload(event: ChangeEvent<HTMLInputElement>) {
    const chosen = Array.from(event.target.files ?? []);
    event.target.value = ""; // lets the same files be chosen again later
    if (chosen.length === 0) return;

    setBusy(true);
    setProblems([]);
    const failed: string[] = [];
    for (const file of chosen) {
      try {
        addFile(item.id, file.name, await readTextFile(file));
      } catch (problem) {
        failed.push(`${file.name}: ${problem instanceof Error ? problem.message : "could not be read."}`);
      }
    }
    setProblems(failed);
    setBusy(false);
  }

  function handleDelete(file: ModuleFile) {
    const confirmed = window.confirm(`Delete the file "${file.name}"?\n\nThis cannot be undone.`);
    if (!confirmed) return;
    if (form?.mode === "edit" && form.id === file.id) setForm(null);
    removeFile(item.id, file.id);
  }

  return (
    <section className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-xl font-bold tracking-tight text-ink">
          Files <span className="text-muted">({files.length})</span>
        </h2>
        <div className="flex flex-wrap gap-2">
          <input
            ref={picker}
            type="file"
            multiple
            onChange={handleUpload}
            className="hidden"
            aria-label="Upload files"
          />
          <button
            type="button"
            onClick={() => picker.current?.click()}
            disabled={busy}
            className="inline-flex items-center gap-2 rounded-xl border border-brand-200 bg-white px-4 py-2.5 text-sm font-semibold text-brand-700 shadow-sm transition hover:bg-brand-50 disabled:cursor-wait disabled:opacity-70"
          >
            <Upload className="h-4 w-4" />
            {busy ? "Uploading…" : "Upload"}
          </button>
          <button
            type="button"
            onClick={() => openForm({ mode: "add" })}
            className="rounded-xl bg-brand-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-brand-700"
          >
            + Add File
          </button>
        </div>
      </div>

      {problems.length > 0 && (
        <div
          role="alert"
          className="space-y-1 rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700"
        >
          <p className="font-semibold">Some files could not be added:</p>
          {problems.map((message) => (
            <p key={message}>{message}</p>
          ))}
        </div>
      )}

      {showForm && form && (
        <div ref={anchor} className="scroll-mt-6">
          <FileForm
            key={form.mode === "edit" ? form.id : "add"}
            initial={
              editing
                ? { name: editing.name, content: editing.content }
                : { name: "", content: "" }
            }
            heading={editing ? `Edit ${editing.name}` : "New file"}
            submitLabel={editing ? "Save changes" : "Add file"}
            takenNames={takenNames}
            onSubmit={(values) => {
              if (form.mode === "edit") {
                updateFile(item.id, form.id, values);
              } else {
                addFile(item.id, values.name, values.content);
              }
              setForm(null);
            }}
            onCancel={() => setForm(null)}
          />
        </div>
      )}

      {files.length === 0 ? (
        !showForm && (
          <p className="max-w-md text-base leading-relaxed text-muted">
            No files yet. Click Add File to type or paste your code, or Upload to add files from your
            computer.
          </p>
        )
      ) : (
        <div className="space-y-5">
          {files.map((file) => {
            const lines = countLines(file.content);
            return (
              <CodeBlock
                key={file.id}
                title={file.name}
                badge={`${describeFile(file.name)} • ${lines} ${lines === 1 ? "line" : "lines"}`}
                text={file.content}
                variant="code"
                emptyMessage="This file is empty. Click Edit to add code."
                actions={
                  <>
                    <PanelButton
                      icon={<Pencil className="h-3.5 w-3.5" />}
                      label="Edit"
                      onClick={() => openForm({ mode: "edit", id: file.id })}
                    />
                    <PanelButton
                      icon={<Trash2 className="h-3.5 w-3.5" />}
                      label="Delete"
                      danger
                      onClick={() => handleDelete(file)}
                    />
                  </>
                }
              />
            );
          })}
        </div>
      )}
    </section>
  );
}
