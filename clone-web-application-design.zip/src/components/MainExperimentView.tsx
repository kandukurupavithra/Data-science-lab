import { BookOpen, ExternalLink, GitBranch, Sparkles, Video } from "lucide-react";
import type { Experiment } from "../data/types";
import { getYouTubeId, youtubeEmbedUrl } from "../lib/youtube";
import { Card } from "./ui";

/** Main experiment tab: summary, overview, YouTube video and GitHub link. */
export function MainExperimentView({ experiment }: { experiment: Experiment }) {
  const videoId = getYouTubeId(experiment.videoUrl);

  return (
    <div className="space-y-6">
      {experiment.summary && (
        <Card title="Summary" icon={<Sparkles className="h-4 w-4" />}>
          <p className="text-sm leading-relaxed text-slate-600">{experiment.summary}</p>
        </Card>
      )}

      <Card title="Overview" icon={<BookOpen className="h-4 w-4" />}>
        <p className="text-sm leading-relaxed text-slate-600">{experiment.overview}</p>
      </Card>

      {experiment.videoUrl && (
        <Card title="YouTube Video" icon={<Video className="h-4 w-4" />}>
          {videoId ? (
            <div className="aspect-video overflow-hidden rounded-xl bg-slate-900 shadow-md">
              <iframe
                src={youtubeEmbedUrl(videoId)}
                title={`${experiment.expNumber} video walkthrough`}
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                referrerPolicy="strict-origin-when-cross-origin"
                allowFullScreen
                className="h-full w-full border-0"
              />
            </div>
          ) : null}
          <a
            href={experiment.videoUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 text-sm font-medium text-purple-700 hover:text-purple-900"
          >
            Watch on YouTube
            <ExternalLink className="h-3.5 w-3.5" />
          </a>
        </Card>
      )}

      {experiment.githubLink && (
        <Card title="GitHub" icon={<GitBranch className="h-4 w-4" />}>
          <a
            href={experiment.githubLink}
            target="_blank"
            rel="noreferrer"
            className="group flex items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm transition hover:border-purple-300 hover:bg-purple-50/50"
          >
            <span className="min-w-0">
              <span className="block font-medium text-slate-900">Source code repository</span>
              <span className="block truncate font-mono text-xs text-slate-500">
                {experiment.githubLink.replace(/^https?:\/\//, "")}
              </span>
            </span>
            <ExternalLink className="h-4 w-4 shrink-0 text-slate-400 transition group-hover:text-purple-600" />
          </a>
        </Card>
      )}
    </div>
  );
}
