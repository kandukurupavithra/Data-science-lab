import { useState } from "react";
import { ArrowLeft, Pencil, Trash2 } from "lucide-react";
import {
  addTopic,
  describeModuleContents,
  removeModule,
  removeTopic,
  updateModule,
  updateTopic,
  useLearningModules,
  type LearningModule,
  type Topic,
} from "../lib/learning";
import { cn } from "../utils/cn";
import { ModuleFiles } from "./ModuleFiles";
import { ModuleForm, TopicForm } from "./LearningForms";

const plural = (count: number, word: string) => `${count} ${word}${count === 1 ? "" : "s"}`;

/** One learning module: its details and the topics inside it. */
export function ModuleDetail({ id }: { id: string }) {
  const modules = useLearningModules();
  const item = modules.find((entry) => entry.id === id);

  if (!item) {
    return (
      <div className="rounded-3xl border border-dashed border-brand-200 bg-white p-10 text-center">
        <p className="text-lg font-bold text-ink">Module not found</p>
        <a
          href="#/modules"
          className="mt-4 inline-flex items-center gap-2 text-sm font-bold text-brand-600 hover:text-brand-700"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to modules
        </a>
      </div>
    );
  }

  return <ModuleView key={item.id} item={item} />;
}

type TopicFormMode = null | { mode: "add" } | { mode: "edit"; id: string };

function ModuleView({ item }: { item: LearningModule }) {
  const [editingModule, setEditingModule] = useState(false);
  const [topicForm, setTopicForm] = useState<TopicFormMode>(null);

  const total = item.topics.length;
  const done = item.topics.filter((topic) => topic.done).length;
  const percent = total === 0 ? 0 : Math.round((done / total) * 100);

  const editingTopic =
    topicForm?.mode === "edit"
      ? (item.topics.find((topic) => topic.id === topicForm.id) ?? null)
      : null;
  const showTopicForm = topicForm?.mode === "add" || editingTopic !== null;

  const handleDeleteModule = () => {
    const contents = describeModuleContents(item);
    const confirmed = window.confirm(
      `Delete the module "${item.title}"${contents ? ` with its ${contents}` : ""}?\n\nThis cannot be undone.`,
    );
    if (!confirmed) return;
    window.location.hash = "#/modules";
    removeModule(item.id);
  };

  const handleDeleteTopic = (topic: Topic) => {
    if (window.confirm(`Delete the topic "${topic.title}"?`)) removeTopic(item.id, topic.id);
  };

  return (
    <div className="space-y-6">
      <a
        href="#/modules"
        className="inline-flex items-center gap-2 text-sm font-medium text-muted transition hover:text-brand-600"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to modules
      </a>

      {editingModule ? (
        <ModuleForm
          initial={{ title: item.title, description: item.description }}
          heading="Edit module"
          submitLabel="Save changes"
          onSubmit={(values) => {
            updateModule(item.id, values);
            setEditingModule(false);
          }}
          onCancel={() => setEditingModule(false)}
        />
      ) : (
        <section className="rounded-3xl border border-brand-100 bg-white/95 p-7 shadow-sm backdrop-blur-sm">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="min-w-0">
              <span className="text-4xl" aria-hidden="true">
                📚
              </span>
              <h1 className="mt-4 text-2xl font-bold tracking-tight text-ink sm:text-3xl">
                {item.title}
              </h1>
              <p className="mt-2 max-w-2xl text-base leading-relaxed text-muted">
                {item.description || "No description yet. Click Edit to add one."}
              </p>
            </div>
            <div className="flex shrink-0 gap-2">
              <button
                type="button"
                onClick={() => setEditingModule(true)}
                className="inline-flex items-center gap-1.5 rounded-xl border border-brand-200 bg-white px-3.5 py-2 text-sm font-semibold text-brand-700 shadow-sm transition hover:bg-brand-50"
              >
                <Pencil className="h-4 w-4" />
                Edit
              </button>
              <button
                type="button"
                onClick={handleDeleteModule}
                className="inline-flex items-center gap-1.5 rounded-xl border border-rose-200 bg-white px-3.5 py-2 text-sm font-semibold text-rose-600 shadow-sm transition hover:bg-rose-50"
              >
                <Trash2 className="h-4 w-4" />
                Delete
              </button>
            </div>
          </div>

          <div className="mt-6 space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="font-semibold text-ink">
                {total === 0 ? "No topics yet" : `${done} of ${plural(total, "topic")} done`}
              </span>
              {total > 0 && <span className="font-bold text-brand-600">{percent}%</span>}
            </div>
            <div
              role="progressbar"
              aria-label="Topics completed"
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={percent}
              className="h-2 overflow-hidden rounded-full bg-brand-100"
            >
              <div
                className="h-full rounded-full bg-brand-600 transition-all"
                style={{ width: `${percent}%` }}
              />
            </div>
          </div>
        </section>
      )}

      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-xl font-bold tracking-tight text-ink">
          Topics <span className="text-muted">({total})</span>
        </h2>
        <button
          type="button"
          onClick={() => setTopicForm({ mode: "add" })}
          className="rounded-xl bg-brand-600 px-5 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-brand-700"
        >
          + Add Topic
        </button>
      </div>

      {showTopicForm && topicForm && (
        <TopicForm
          key={topicForm.mode === "edit" ? topicForm.id : "add"}
          initial={
            editingTopic
              ? { title: editingTopic.title, notes: editingTopic.notes }
              : { title: "", notes: "" }
          }
          heading={editingTopic ? "Edit topic" : "New topic"}
          submitLabel={editingTopic ? "Save changes" : "Add topic"}
          onSubmit={(values) => {
            if (topicForm.mode === "edit") {
              updateTopic(item.id, topicForm.id, values);
            } else {
              addTopic(item.id, values.title, values.notes);
            }
            setTopicForm(null);
          }}
          onCancel={() => setTopicForm(null)}
        />
      )}

      {total === 0 ? (
        !showTopicForm && (
          <p className="max-w-sm text-base leading-relaxed text-muted">
            No topics yet. Click Add Topic to begin.
          </p>
        )
      ) : (
        <ol className="space-y-4">
          {item.topics.map((topic, index) => (
            <li
              key={topic.id}
              className="flex gap-4 rounded-3xl border border-brand-100 bg-white/95 p-5 shadow-sm backdrop-blur-sm"
            >
              <input
                type="checkbox"
                checked={topic.done}
                onChange={(event) => updateTopic(item.id, topic.id, { done: event.target.checked })}
                aria-label={`Mark "${topic.title}" as done`}
                className="mt-1 h-5 w-5 shrink-0 cursor-pointer accent-brand-600"
              />
              <div className="min-w-0 flex-1">
                <div className="flex items-start justify-between gap-3">
                  <h3
                    className={cn(
                      "text-lg font-bold leading-snug",
                      topic.done ? "text-muted line-through" : "text-ink",
                    )}
                  >
                    <span className="mr-2 font-mono text-sm font-semibold text-brand-600 no-underline">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    {topic.title}
                  </h3>
                  <div className="-mr-2 -mt-1 flex shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        setTopicForm({ mode: "edit", id: topic.id });
                        window.scrollTo({ top: 0, behavior: "smooth" });
                      }}
                      aria-label={`Edit ${topic.title}`}
                      title="Edit topic"
                      className="rounded-full p-2 text-muted transition hover:bg-brand-50 hover:text-brand-600"
                    >
                      <Pencil className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteTopic(topic)}
                      aria-label={`Delete ${topic.title}`}
                      title="Delete topic"
                      className="rounded-full p-2 text-rose-300 transition hover:bg-rose-50 hover:text-rose-500"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                {topic.notes ? (
                  <p className="mt-2 whitespace-pre-wrap break-words text-base leading-relaxed text-muted">
                    {topic.notes}
                  </p>
                ) : (
                  <p className="mt-2 text-sm text-muted">No notes yet.</p>
                )}
              </div>
            </li>
          ))}
        </ol>
      )}

      <ModuleFiles item={item} />
    </div>
  );
}
