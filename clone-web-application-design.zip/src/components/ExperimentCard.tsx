import { ArrowRight, Layers, Pencil, Trash2 } from "lucide-react";
import type { Experiment } from "../data/types";

interface ExperimentCardProps {
  experiment: Experiment;
  onEdit: () => void;
  onDelete: () => void;
}

export function ExperimentCard({ experiment, onEdit, onDelete }: ExperimentCardProps) {
  return (
    <article className="group relative flex flex-col overflow-hidden rounded-3xl border border-brand-100 bg-white/95 shadow-sm backdrop-blur-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-brand-100">
      <div className="relative h-44 overflow-hidden bg-gradient-to-br from-brand-500 to-purple-800">
        {experiment.coverPhoto && (
          <img
            src={experiment.coverPhoto}
            alt=""
            loading="lazy"
            className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-slate-900/10 to-transparent" />
        <span className="absolute left-4 top-4 rounded-lg bg-brand-600 px-2.5 py-1 text-xs font-bold text-white shadow-sm">
          {experiment.expNumber}
        </span>
        <span className="absolute right-4 top-4 rounded-full bg-white/95 px-2.5 py-1 text-xs font-semibold text-emerald-700 shadow-sm">
          {experiment.status}
        </span>

        <div className="absolute bottom-3 right-3 z-10 flex gap-2">
          <button
            type="button"
            onClick={onEdit}
            aria-label={`Edit ${experiment.expNumber}`}
            title="Edit experiment"
            className="rounded-full bg-white/95 p-2 text-brand-700 shadow-sm transition hover:bg-white"
          >
            <Pencil className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={onDelete}
            aria-label={`Delete ${experiment.expNumber}`}
            title="Delete experiment"
            className="rounded-full bg-white/95 p-2 text-rose-500 shadow-sm transition hover:bg-white hover:text-rose-600"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="flex flex-1 flex-col gap-3 p-6">
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="rounded-full bg-brand-50 px-2.5 py-1 font-semibold text-brand-700 ring-1 ring-inset ring-brand-200">
            {experiment.category}
          </span>
          <span className="text-muted">
            {experiment.sem} • {experiment.subject}
          </span>
        </div>
        <h3 className="text-lg font-bold leading-snug tracking-tight text-ink">
          {/* The link stretches over the whole card; the edit and delete buttons sit above it. */}
          <a
            href={`#/experiment/${experiment.id}`}
            className="outline-none after:absolute after:inset-0 focus-visible:after:rounded-3xl focus-visible:after:ring-4 focus-visible:after:ring-brand-300"
          >
            {experiment.title}
          </a>
        </h3>
        <p className="line-clamp-3 text-sm leading-relaxed text-muted">
          {experiment.overview || "No overview yet."}
        </p>

        <div className="mt-auto flex items-center justify-between border-t border-brand-50 pt-4 text-sm">
          <span className="inline-flex items-center gap-1.5 text-muted">
            <Layers className="h-4 w-4" />
            {experiment.subExperiments.length} sub-experiments
          </span>
          <span className="inline-flex items-center gap-1 font-bold text-brand-600 transition-all group-hover:gap-2">
            Open <ArrowRight className="h-4 w-4" />
          </span>
        </div>
      </div>
    </article>
  );
}
