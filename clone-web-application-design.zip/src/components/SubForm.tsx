import { useState, type FormEvent } from "react";
import { CodeInput } from "./CodeBlock";
import { Field, FormButtons, FormCard, INPUT_CLASS } from "./form";

export interface SubFormValues {
  title: string;
  overview: string;
  code: string;
  output: string;
}

interface SubFormProps {
  initial: SubFormValues;
  heading: string;
  submitLabel: string;
  onSubmit: (values: SubFormValues) => void;
  onCancel: () => void;
}

const clean = (value: string) => value.replace(/\r\n/g, "\n").trimEnd();

/** Form for adding or editing a sub-experiment: title, summary, and the code and output typed by hand. */
export function SubForm({ initial, heading, submitLabel, onSubmit, onCancel }: SubFormProps) {
  const [values, setValues] = useState<SubFormValues>(initial);
  const update = (key: keyof SubFormValues) => (value: string) =>
    setValues((current) => ({ ...current, [key]: value }));

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (!values.title.trim()) return;
    onSubmit({
      title: values.title.trim(),
      overview: values.overview.trim(),
      code: clean(values.code),
      output: clean(values.output),
    });
  }

  return (
    <FormCard title={heading} onSubmit={handleSubmit}>
      <Field label="Title">
        <input
          autoFocus
          value={values.title}
          onChange={(event) => update("title")(event.target.value)}
          placeholder="e.g. Reading a CSV file"
          className={INPUT_CLASS}
        />
      </Field>

      <Field label="Summary">
        <textarea
          rows={3}
          value={values.overview}
          onChange={(event) => update("overview")(event.target.value)}
          placeholder="What does this sub-experiment demonstrate?"
          className={INPUT_CLASS}
        />
      </Field>

      <Field label="Code" hint="Type or paste your Python code. Tab inserts spaces; press Esc then Tab to leave the box.">
        <CodeInput
          variant="code"
          label="Code"
          value={values.code}
          onChange={update("code")}
          placeholder="import pandas as pd"
        />
      </Field>

      <Field label="Output" hint="Paste the output your program produced, exactly as it should appear.">
        <CodeInput
          variant="output"
          label="Output"
          value={values.output}
          onChange={update("output")}
          placeholder="Paste the output here"
          minRows={5}
        />
      </Field>

      <FormButtons submitLabel={submitLabel} disabled={!values.title.trim()} onCancel={onCancel} />
    </FormCard>
  );
}
