import { ExternalLink } from "lucide-react";
import { tools } from "../data/tools";
import { PageHeading } from "./ui";

export function Tools() {
  return (
    <div className="space-y-8">
      <PageHeading
        title="Learning Tools"
        subtitle="Useful platforms for coding, datasets and visualization."
      />

      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {tools.map((tool) => (
          <a
            key={tool.name}
            href={tool.url}
            target="_blank"
            rel="noreferrer"
            className="group flex flex-col rounded-3xl border border-brand-100 bg-white/95 p-7 shadow-sm backdrop-blur-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-brand-100"
          >
            <div className="flex items-start justify-between gap-3">
              <span className="text-4xl" aria-hidden="true">
                {tool.emoji}
              </span>
              <span className="rounded-full bg-brand-50 px-2.5 py-1 text-xs font-semibold text-brand-700 ring-1 ring-inset ring-brand-200">
                {tool.category}
              </span>
            </div>
            <h3 className="mt-6 text-xl font-bold text-ink">{tool.name}</h3>
            <p className="mt-3 flex-1 text-base leading-relaxed text-muted">{tool.description}</p>
            <span className="mt-6 inline-flex items-center gap-1.5 text-base font-bold text-brand-600">
              Open {tool.name}
              <ExternalLink className="h-4 w-4 transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </span>
          </a>
        ))}
      </div>
    </div>
  );
}
