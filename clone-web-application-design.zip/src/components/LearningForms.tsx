import { useRef, useState, type ChangeEvent, type FormEvent } from "react";
import { Upload } from "lucide-react";
import { cleanFileName, readTextFile } from "../lib/files";
import { CodeInput } from "./CodeBlock";
import { Field, FormButtons, FormCard, INPUT_CLASS } from "./form";

export interface ModuleFormValues {
  title: string;
  description: string;
}

export interface TopicFormValues {
  title: string;
  notes: string;
}

export interface FileFormValues {
  name: string;
  content: string;
}

interface FormProps<T> {
  initial: T;
  heading: string;
  submitLabel: string;
  onSubmit: (values: T) => void;
  onCancel: () => void;
}

/** Form for creating or renaming a learning module. */
export function ModuleForm({
  initial,
  heading,
  submitLabel,
  onSubmit,
  onCancel,
}: FormProps<ModuleFormValues>) {
  const [values, setValues] = useState(initial);

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (!values.title.trim()) return;
    onSubmit({ title: values.title.trim(), description: values.description.trim() });
  }

  return (
    <FormCard title={heading} onSubmit={handleSubmit}>
      <Field label="Module name">
        <input
          autoFocus
          value={values.title}
          onChange={(event) => setValues((current) => ({ ...current, title: event.target.value }))}
          placeholder="e.g. Python Basics"
          className={INPUT_CLASS}
        />
      </Field>
      <Field label="Description" hint="Optional. What will you learn in this module?">
        <textarea
          rows={3}
          value={values.description}
          onChange={(event) =>
            setValues((current) => ({ ...current, description: event.target.value }))
          }
          placeholder="A short description of the module"
          className={INPUT_CLASS}
        />
      </Field>
      <FormButtons submitLabel={submitLabel} disabled={!values.title.trim()} onCancel={onCancel} />
    </FormCard>
  );
}

/** Form for adding or editing a topic inside a module. */
export function TopicForm({
  initial,
  heading,
  submitLabel,
  onSubmit,
  onCancel,
}: FormProps<TopicFormValues>) {
  const [values, setValues] = useState(initial);

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (!values.title.trim()) return;
    onSubmit({ title: values.title.trim(), notes: values.notes.replace(/\s+$/, "") });
  }

  return (
    <FormCard title={heading} onSubmit={handleSubmit}>
      <Field label="Topic title">
        <input
          autoFocus
          value={values.title}
          onChange={(event) => setValues((current) => ({ ...current, title: event.target.value }))}
          placeholder="e.g. Lists and dictionaries"
          className={INPUT_CLASS}
        />
      </Field>
      <Field label="Notes" hint="Optional. Write what you learned, key points or examples.">
        <textarea
          rows={6}
          value={values.notes}
          onChange={(event) => setValues((current) => ({ ...current, notes: event.target.value }))}
          placeholder="Your notes for this topic"
          className={INPUT_CLASS}
        />
      </Field>
      <FormButtons submitLabel={submitLabel} disabled={!values.title.trim()} onCancel={onCancel} />
    </FormCard>
  );
}

interface FileFormProps extends FormProps<FileFormValues> {
  /** Lower-case names of the other files in the module. A new name must not match one of them. */
  takenNames: string[];
}

/** Form for adding or editing a file: its name and the code typed, pasted or loaded from the computer. */
export function FileForm({
  initial,
  heading,
  submitLabel,
  takenNames,
  onSubmit,
  onCancel,
}: FileFormProps) {
  const [values, setValues] = useState(initial);
  const [error, setError] = useState<string | null>(null);
  const picker = useRef<HTMLInputElement>(null);

  const hasName = values.name.trim() !== "";
  const cleanedName = cleanFileName(values.name);
  const duplicate = hasName && takenNames.includes(cleanedName.toLowerCase());
  const canSave = hasName && !duplicate;

  async function handlePick(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = ""; // lets the same file be chosen again later
    if (!file) return;

    try {
      const content = await readTextFile(file);
      setValues((current) => ({
        name: current.name.trim() ? current.name : file.name,
        content,
      }));
      setError(null);
    } catch (problem) {
      setError(problem instanceof Error ? problem.message : "That file could not be read.");
    }
  }

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (!canSave) return;
    onSubmit({
      name: cleanedName,
      content: values.content.replace(/\r\n/g, "\n").replace(/\s+$/, ""),
    });
  }

  return (
    <FormCard title={heading} onSubmit={handleSubmit}>
      <Field label="File name" hint="Include the extension, for example analysis.py or notes.txt.">
        <input
          autoFocus
          value={values.name}
          onChange={(event) => setValues((current) => ({ ...current, name: event.target.value }))}
          placeholder="analysis.py"
          className={INPUT_CLASS}
        />
      </Field>
      {duplicate && (
        <p role="alert" className="-mt-2 text-sm font-medium text-rose-600">
          A file with this name already exists in this module.
        </p>
      )}

      <Field
        label="Code"
        hint="Type or paste your code. Tab inserts spaces; press Esc then Tab to leave the box."
      >
        <CodeInput
          variant="code"
          label="File content"
          value={values.content}
          onChange={(content) => setValues((current) => ({ ...current, content }))}
          placeholder="import pandas as pd"
        />
      </Field>

      <div className="flex flex-wrap items-center gap-3">
        <input ref={picker} type="file" onChange={handlePick} className="hidden" aria-label="Choose a file" />
        <button
          type="button"
          onClick={() => picker.current?.click()}
          className="inline-flex items-center gap-2 rounded-xl border border-brand-200 bg-white px-4 py-2 text-sm font-semibold text-brand-700 transition hover:bg-brand-50"
        >
          <Upload className="h-4 w-4" />
          Load from computer
        </button>
        <span className="text-xs text-muted">Replaces the code above with the chosen file.</span>
      </div>
      {error && (
        <p role="alert" className="text-sm font-medium text-rose-600">
          {error}
        </p>
      )}

      <FormButtons submitLabel={submitLabel} disabled={!canSave} onCancel={onCancel} />
    </FormCard>
  );
}
