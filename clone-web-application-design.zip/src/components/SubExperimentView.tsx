import { useState } from "react";
import { Pencil, Plus, Sparkles, Trash2 } from "lucide-react";
import type { SubExperiment } from "../data/types";
import { CodeBlock, PanelButton } from "./CodeBlock";
import { SubForm, type SubFormValues } from "./SubForm";
import { Card } from "./ui";

interface SubExperimentViewProps {
  sub: SubExperiment;
  onSave: (values: SubFormValues) => void;
  onDelete: () => void;
}

type Field = "code" | "output";

/** A sub-experiment tab: summary, code and output, all typed in by the student. */
export function SubExperimentView({ sub, onSave, onDelete }: SubExperimentViewProps) {
  const [editing, setEditing] = useState(false);

  if (editing) {
    return (
      <SubForm
        initial={{ title: sub.title, overview: sub.overview, code: sub.code, output: sub.output }}
        heading={`Edit ${sub.subExpNumber}`}
        submitLabel="Save changes"
        onSubmit={(values) => {
          onSave(values);
          setEditing(false);
        }}
        onCancel={() => setEditing(false)}
      />
    );
  }

  /** Empties the code or the output so a new one can be added with Edit. */
  function clearField(field: Field) {
    const confirmed = window.confirm(
      `Delete the ${field} of ${sub.subExpNumber}?\n\nYou can add new ${field} afterwards.`,
    );
    if (!confirmed) return;
    onSave({
      title: sub.title,
      overview: sub.overview,
      code: field === "code" ? "" : sub.code,
      output: field === "output" ? "" : sub.output,
    });
  }

  function actionsFor(field: Field) {
    if (sub[field].trim() === "") {
      return (
        <PanelButton
          icon={<Plus className="h-3.5 w-3.5" />}
          label={`Add ${field}`}
          onClick={() => setEditing(true)}
        />
      );
    }
    return (
      <>
        <PanelButton
          icon={<Pencil className="h-3.5 w-3.5" />}
          label="Edit"
          onClick={() => setEditing(true)}
        />
        <PanelButton
          icon={<Trash2 className="h-3.5 w-3.5" />}
          label="Delete"
          danger
          onClick={() => clearField(field)}
        />
      </>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0 space-y-1">
          <span className="font-mono text-xs font-semibold text-brand-600">{sub.subExpNumber}</span>
          <h2 className="text-2xl font-bold tracking-tight text-ink">{sub.title}</h2>
        </div>
        <div className="flex shrink-0 gap-2">
          <button
            type="button"
            onClick={() => setEditing(true)}
            className="inline-flex items-center gap-1.5 rounded-xl border border-brand-200 bg-white px-3.5 py-2 text-sm font-semibold text-brand-700 shadow-sm transition hover:bg-brand-50"
          >
            <Pencil className="h-4 w-4" />
            Edit
          </button>
          <button
            type="button"
            onClick={onDelete}
            className="inline-flex items-center gap-1.5 rounded-xl border border-rose-200 bg-white px-3.5 py-2 text-sm font-semibold text-rose-600 shadow-sm transition hover:bg-rose-50"
          >
            <Trash2 className="h-4 w-4" />
            Delete
          </button>
        </div>
      </div>

      <Card title="Summary" icon={<Sparkles className="h-4 w-4" />}>
        {sub.overview ? (
          <p className="text-sm leading-relaxed text-slate-600">{sub.overview}</p>
        ) : (
          <p className="text-sm text-muted">No summary yet. Click Edit to add one.</p>
        )}
      </Card>

      <CodeBlock
        title="Code"
        badge="Python"
        text={sub.code}
        variant="code"
        emptyMessage="No code yet. Click Add code to type or paste your own."
        actions={actionsFor("code")}
      />

      <CodeBlock
        title="Output"
        text={sub.output}
        variant="output"
        emptyMessage="No output yet. Click Add output to paste the result."
        actions={actionsFor("output")}
      />
    </div>
  );
}
