export interface LearningTool {
  name: string;
  emoji: string;
  category: string;
  description: string;
  url: string;
}

export const tools: LearningTool[] = [
  {
    name: "Google Colab",
    emoji: "📓",
    category: "Coding",
    description: "Run Python notebooks in the cloud, with free access to GPUs.",
    url: "https://colab.research.google.com",
  },
  {
    name: "Jupyter",
    emoji: "🪐",
    category: "Coding",
    description: "Interactive notebooks that combine code, text and charts.",
    url: "https://jupyter.org/try",
  },
  {
    name: "Kaggle",
    emoji: "🏆",
    category: "Datasets",
    description: "Public datasets, competitions and community notebooks.",
    url: "https://www.kaggle.com",
  },
  {
    name: "GitHub",
    emoji: "🐙",
    category: "Version control",
    description: "Host your code and keep a history of your lab work.",
    url: "https://github.com",
  },
  {
    name: "Tableau Public",
    emoji: "📊",
    category: "Visualization",
    description: "Build and share interactive dashboards for free.",
    url: "https://public.tableau.com",
  },
  {
    name: "Matplotlib Gallery",
    emoji: "🎨",
    category: "Visualization",
    description: "Browse plot examples with ready-to-copy code.",
    url: "https://matplotlib.org/stable/gallery/index.html",
  },
];
