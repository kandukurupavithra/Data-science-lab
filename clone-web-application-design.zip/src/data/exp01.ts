import type { Experiment } from "./types";

export const exp01: Experiment = {
  id: 1,
  expNumber: "EXP-01",
  title: "DATA FORMATS USING PYTHON",
  category: "Classification",
  sem: "Semester V",
  subject: "Data Science",
  coverPhoto:
    "https://images.pexels.com/photos/2004161/pexels-photo-2004161.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  overview:
    "Comprehensive study and practical implementation of data formats using Python: CSV, Tab-delimited files, JSON serialization/deserialization, online URL datasets, and Microsoft Excel spreadsheets using Pandas.",
  summary:
    "Successfully learned to read, write, parse, and manipulate multiple file formats in Python using Pandas, JSON, and standard libraries.",
  code: `import pandas as pd
import json

print("=== EXP-01: DATA FORMATS USING PYTHON ===")
# Working with multiple structured data formats
students = [
    {"Student_ID": 101, "Name": "Pavitra", "Semester": "Sem V", "Subject": "Data Science", "Score": 96},
    {"Student_ID": 102, "Name": "Aarav", "Semester": "Sem V", "Subject": "Data Science", "Score": 92},
    {"Student_ID": 103, "Name": "David", "Semester": "Sem V", "Subject": "Data Science", "Score": 88},
    {"Student_ID": 104, "Name": "Lin", "Semester": "Sem V", "Subject": "Data Science", "Score": 94}
]
df = pd.DataFrame(students)
print("DataFrame Loaded:")
print(df)

# Write to JSON
df.to_json("students.json", orient="records", indent=4)
print("\\nSuccessfully written to students.json")
`,
  pythonLibs: "pandas, numpy, json, openpyxl, requests",
  videoUrl: "https://www.youtube.com/watch?v=vmEHCJofslg",
  githubLink: "https://github.com/kandukurupavithra/Data-science-Experiments",
  output: `=== EXP-01: DATA FORMATS USING PYTHON ===
DataFrame Loaded:
   Student_ID     Name Semester       Subject  Score
0         101  Pavitra    Sem V  Data Science     96
1         102    Aarav    Sem V  Data Science     92
2         103    David    Sem V  Data Science     88
3         104      Lin    Sem V  Data Science     94

Successfully written to students.json`,
  status: "Completed",
  orderIndex: 1,
  subExperiments: [
    {
      subExpNumber: "EXP-01.A.1",
      title: "Online CSV data Set",
      overview:
        "An online CSV dataset is a collection of structured data stored in CSV format and available on the internet. It can be downloaded and loaded into Pandas using pd.read_csv() for data analysis and visualization.",
      code: `import pandas as pd
url = "https://raw.githubusercontent.com/cs109/2014_data/master/countries.csv"
try:
    df = pd.read_csv(url)
    print("=== Loaded Online CSV Dataset ===")
    print(df.head(5))
except Exception as e:
    import io
    csv = """Country,Region\\nAlgeria,AFRICA\\nAngola,AFRICA\\nBenin,AFRICA"""
    df = pd.read_csv(io.StringIO(csv))
    print(df)`,
      output: `=== Loaded Online CSV Dataset ===
        Country  Region
0       Algeria  AFRICA
1        Angola  AFRICA
2         Benin  AFRICA
3      Botswana  AFRICA
4  Burkina Faso  AFRICA`,
      pythonLibs: "pandas, urllib",
    },
    {
      subExpNumber: "EXP-01.A.2",
      title: "writing data into csv file",
      overview:
        "Writing data into a CSV file means saving a Pandas DataFrame as a CSV file using the to_csv() function. It is useful for storing and sharing processed data.",
      code: `import pandas as pd
data = {"ID": [1, 2, 3], "Name": ["Pavitra", "Aarav", "David"], "Score": [96, 92, 88]}
df = pd.DataFrame(data)
df.to_csv("students.csv", index=False)
print("=== CSV Written Successfully ===")
print(open("students.csv").read())`,
      output: `=== CSV Written Successfully ===
ID,Name,Score
1,Pavitra,96
2,Aarav,92
3,David,88`,
      pythonLibs: "pandas",
    },
    {
      subExpNumber: "EXP-01.A.3",
      title: "Reading Tab-Delimited File",
      overview:
        "A tab-delimited file stores data with columns separated by tab spaces (\\t). Pandas can read it using the read_csv() function with sep='\\t'.",
      code: `import pandas as pd
import io
tsv_data = "RollNo\\tName\\tGrade\\n101\\tPavitra\\tA+\\n102\\tAarav\\tA"
df = pd.read_csv(io.StringIO(tsv_data), sep="\\t")
print("=== Tab-Delimited Data Loaded ===")
print(df)`,
      output: `=== Tab-Delimited Data Loaded ===
   RollNo     Name Grade
0     101  Pavitra    A+
1     102    Aarav     A`,
      pythonLibs: "pandas",
    },
    {
      subExpNumber: "EXP-01.B.1",
      title: "Writing data Into Json file",
      overview:
        "Writing data into a JSON file means saving a Pandas DataFrame in JSON format using the to_json() function. It is commonly used for storing and sharing structured data.",
      code: `import pandas as pd
import json

data = [
    {"Student_ID": 101, "Name": "Pavitra", "Semester": "Sem V", "Subject": "Data Science", "Score": 96},
    {"Student_ID": 102, "Name": "Aarav", "Semester": "Sem V", "Subject": "Data Science", "Score": 92},
    {"Student_ID": 103, "Name": "David", "Semester": "Sem V", "Subject": "Data Science", "Score": 88},
    {"Student_ID": 104, "Name": "Lin", "Semester": "Sem V", "Subject": "Data Science", "Score": 94}
]
df = pd.DataFrame(data)
print("=== ORIGINAL DATAFRAME ===")
print(df)

json_file = "students.json"
df.to_json(json_file, orient="records", indent=4)
print(f"\\n[SUCCESS] Successfully written {len(df)} records to '{json_file}'")
print("\\n=== WRITTEN JSON CONTENT ===")
with open(json_file, "r") as f:
    print(f.read())`,
      output: `=== ORIGINAL DATAFRAME ===
   Student_ID     Name Semester       Subject  Score
0         101  Pavitra    Sem V  Data Science     96
1         102    Aarav    Sem V  Data Science     92
2         103    David    Sem V  Data Science     88
3         104      Lin    Sem V  Data Science     94

[SUCCESS] Successfully written 4 records to 'students.json'

=== WRITTEN JSON CONTENT ===
[
    {
        "Student_ID":101,
        "Name":"Pavitra",
        "Semester":"Sem V",
        "Subject":"Data Science",
        "Score":96
    },
    {
        "Student_ID":102,
        "Name":"Aarav",
        "Semester":"Sem V",
        "Subject":"Data Science",
        "Score":92
    },
    {
        "Student_ID":103,
        "Name":"David",
        "Semester":"Sem V",
        "Subject":"Data Science",
        "Score":88
    },
    {
        "Student_ID":104,
        "Name":"Lin",
        "Semester":"Sem V",
        "Subject":"Data Science",
        "Score":94
    }
]`,
      pythonLibs: "pandas, json",
    },
    {
      subExpNumber: "EXP-01.B.2",
      title: "Reading JSON file",
      overview:
        "Reading a JSON file means loading JSON-formatted data into a Pandas DataFrame using the read_json() function.",
      code: `import pandas as pd
import json

students_json = """[
    {"Student_ID": 101, "Name": "Pavitra", "Semester": "Sem V", "Subject": "Data Science", "Score": 96},
    {"Student_ID": 102, "Name": "Aarav", "Semester": "Sem V", "Subject": "Data Science", "Score": 92},
    {"Student_ID": 103, "Name": "David", "Semester": "Sem V", "Subject": "Data Science", "Score": 88},
    {"Student_ID": 104, "Name": "Lin", "Semester": "Sem V", "Subject": "Data Science", "Score": 94}
]"""
from io import StringIO
df = pd.read_json(StringIO(students_json))
print(df)`,
      output: "",
      pythonLibs: "pandas, json",
    },
  ],
};
