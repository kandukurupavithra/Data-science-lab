import type { Experiment } from "./types";

export const exp03: Experiment = {
  id: 3,
  expNumber: "EXP-03",
  title: "Data Cleaing and Preparation",
  category: "Data Preprocessing",
  sem: "Semester V",
  subject: "Data Science",
  coverPhoto:
    "https://images.pexels.com/photos/17485657/pexels-photo-17485657.png?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  overview:
    "Data cleaning and preparation techniques: handling missing values (NaN imputation, dropping), data transformations, outlier detection using statistical thresholds, and string regular expressions for text cleaning.",
  summary:
    "Identified and imputed missing entries, eliminated extreme outliers, and standardized data types across all fields.",
  code: `import pandas as pd
import numpy as np

data = {"Name": ["Pavitra", "Aarav", np.nan, "Lin"], "Age": [20, np.nan, 21, 22], "Score": [96, 92, 88, 94]}
df = pd.DataFrame(data)
print("=== RAW DIRTY DATASET ===")
print(df)

# Impute missing values
df["Name"] = df["Name"].fillna("Anonymous")
df["Age"] = df["Age"].fillna(df["Age"].median())
print("\\n=== CLEANED DATASET ===")
print(df)`,
  pythonLibs: "pandas, numpy, re",
  videoUrl: "https://www.youtube.com/watch?v=J4Wdy0Wc_xQ",
  githubLink: "https://github.com/kandukurupavithra/Data-science-Experiments",
  output: `=== RAW DIRTY DATASET ===
      Name   Age  Score
0  Pavitra  20.0     96
1    Aarav   NaN     92
2      NaN  21.0     88
3      Lin  22.0     94

=== CLEANED DATASET ===
        Name   Age  Score
0    Pavitra  20.0     96
1      Aarav  21.0     92
2  Anonymous  21.0     88
3        Lin  22.0     94`,
  status: "Completed",
  orderIndex: 3,
  subExperiments: [
    {
      subExpNumber: "EXP-03.1",
      title: "Handle Missing Data",
      overview:
        "Detecting and treating missing values using isnull(), dropna(), and fillna().",
      code: `import pandas as pd
import numpy as np
df = pd.DataFrame({"A": [1, np.nan, 3], "B": [np.nan, 5, 6]})
print("Missing values summary:")
print(df.isnull().sum())
print("\\nFilled with column mean:")
print(df.fillna(df.mean()))`,
      output: `Missing values summary:
A    1
B    1
dtype: int64

Filled with column mean:
     A    B
0  1.0  5.5
1  2.0  5.0
2  3.0  6.0`,
      pythonLibs: "pandas, numpy",
    },
    {
      subExpNumber: "EXP-03.2",
      title: "Data Transforming",
      overview:
        "Transforming categorical variables, mapping dictionaries, and standardizing scale.",
      code: `import pandas as pd
df = pd.DataFrame({"Grade": ["A", "B", "A", "C"]})
mapping = {"A": 4.0, "B": 3.0, "C": 2.0}
df["GPA"] = df["Grade"].map(mapping)
print(df)`,
      output: `  Grade  GPA
0     A  4.0
1     B  3.0
2     A  4.0
3     C  2.0`,
      pythonLibs: "pandas",
    },
    {
      subExpNumber: "EXP-03.3",
      title: "outlinoor",
      overview: "Outlier detection using Interquartile Range (IQR) bounds.",
      code: `import numpy as np
import pandas as pd
scores = pd.Series([90, 92, 94, 96, 91, 95, 20, 180])
q25, q75 = scores.quantile(0.25), scores.quantile(0.75)
iqr = q75 - q25
lower = q25 - 1.5 * iqr
upper = q75 + 1.5 * iqr
outliers = scores[(scores < lower) | (scores > upper)]
print(f"IQR bounds: [{lower}, {upper}]")
print(f"Detected outliers: {list(outliers)}")`,
      output: `IQR bounds: [83.625, 102.625]
Detected outliers: [20, 180]`,
      pythonLibs: "pandas, numpy",
    },
    {
      subExpNumber: "EXP-03.4",
      title: "Regex for Manipulation",
      overview: "String manipulation with regular expressions in Pandas.",
      code: `import re
import pandas as pd
emails = pd.Series(["pavitra@mbu.edu", "invalid-email", "aarav@gmail.com"])
pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$"
valid = emails.str.contains(pattern)
print(pd.DataFrame({"Email": emails, "Valid": valid}))`,
      output: `             Email  Valid
0  pavitra@mbu.edu   True
1    invalid-email  False
2  aarav@gmail.com   True`,
      pythonLibs: "pandas, re",
    },
  ],
};
