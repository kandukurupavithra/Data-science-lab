export interface SubExperiment {
  subExpNumber: string;
  title: string;
  overview: string;
  code: string;
  output: string;
  pythonLibs: string;
}

export interface Experiment {
  id: number;
  expNumber: string;
  title: string;
  category: string;
  sem: string;
  subject: string;
  coverPhoto: string;
  overview: string;
  summary: string | null;
  code: string;
  output: string;
  pythonLibs: string;
  videoUrl: string | null;
  githubLink: string | null;
  status: string;
  orderIndex: number;
  subExperiments: SubExperiment[];
}
