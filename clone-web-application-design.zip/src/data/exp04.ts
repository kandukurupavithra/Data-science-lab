import type { Experiment } from "./types";

export const exp04: Experiment = {
  id: 4,
  expNumber: "EXP-04",
  title: "Data Wrangling",
  category: "Data Preprocessing",
  sem: "Semester V",
  subject: "Data Science",
  coverPhoto:
    "https://images.pexels.com/photos/17484970/pexels-photo-17484970.png?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  overview:
    "Advanced Data Wrangling in Pandas: Hierarchical Multi-Indexing at inner and outer levels, Stack and Unstack reshape operations, and joining disparate DataFrames.",
  summary:
    "Mastered reshaping complex nested datasets and joining multiple data sources with inner/outer merges.",
  code: `import pandas as pd
import numpy as np

# Hierarchical Indexing
index = pd.MultiIndex.from_tuples([
    ('Sem V', 'Pavitra'), ('Sem V', 'Aarav'),
    ('Sem VI', 'Pavitra'), ('Sem VI', 'Aarav')
], names=['Semester', 'Student'])

df = pd.DataFrame({'Data_Science': [96, 92, 98, 94]}, index=index)
print("=== HIERARCHICAL MULTI-INDEX DATAFRAME ===")
print(df)

# Unstack to wide format
print("\\n=== UNSTACKED RESHAPED FORMAT ===")
print(df.unstack())`,
  pythonLibs: "pandas, numpy",
  videoUrl: "https://www.youtube.com/watch?v=QXOkPtLMRvA",
  githubLink: "https://github.com/kandukurupavithra/Data-science-Experiments",
  output: `=== HIERARCHICAL MULTI-INDEX DATAFRAME ===
                  Data_Science
Semester Student              
Sem V    Pavitra            96
         Aarav              92
Sem VI   Pavitra            98
         Aarav              94

=== UNSTACKED RESHAPED FORMAT ===
        Data_Science      
Student        Aarav Pavitra
Semester                    
Sem V             92      96
Sem VI            94      98`,
  status: "Completed",
  orderIndex: 4,
  subExperiments: [
    {
      subExpNumber: "EXP-04.1",
      title: "Herarichal Indexing at outer and inner levels",
      overview: "Creating and querying multi-level indexes in Pandas.",
      code: `import pandas as pd
arrays = [["DS", "DS", "AI", "AI"], [2023, 2024, 2023, 2024]]
index = pd.MultiIndex.from_arrays(arrays, names=["Course", "Year"])
df = pd.DataFrame({"Enrollments": [45, 52, 38, 48]}, index=index)
print(df)
print("\\nQuery DS only:")
print(df.loc["DS"])`,
      output: `             Enrollments
Course Year             
DS     2023           45
       2024           52
AI     2023           38
       2024           48

Query DS only:
      Enrollments
Year             
2023           45
2024           52`,
      pythonLibs: "pandas",
    },
    {
      subExpNumber: "EXP-04.2",
      title: "Stack and Unstack method",
      overview:
        "Pivoting column levels to index (stack) and index levels to columns (unstack).",
      code: `import pandas as pd
df = pd.DataFrame([[96, 92], [94, 90]], index=["Pavitra", "Aarav"], columns=["Exam1", "Exam2"])
print("Original:")
print(df)
print("\\nStacked:")
print(df.stack())`,
      output: `Original:
         Exam1  Exam2
Pavitra     96     92
Aarav       94     90

Stacked:
Pavitra  Exam1    96
         Exam2    92
Aarav    Exam1    94
         Exam2    90
dtype: int64`,
      pythonLibs: "pandas",
    },
    {
      subExpNumber: "EXP-04.3",
      title: "different pandas data frames",
      overview: "Merging and concatenating different Pandas DataFrames.",
      code: `import pandas as pd
df1 = pd.DataFrame({"ID": [101, 102], "Name": ["Pavitra", "Aarav"]})
df2 = pd.DataFrame({"ID": [101, 102], "Score": [96, 92]})
merged = pd.merge(df1, df2, on="ID")
print("Merged DataFrame:")
print(merged)`,
      output: `Merged DataFrame:
    ID     Name  Score
0  101  Pavitra     96
1  102    Aarav     92`,
      pythonLibs: "pandas",
    },
  ],
};
