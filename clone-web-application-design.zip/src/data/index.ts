import { exp01 } from "./exp01";
import { exp02 } from "./exp02";
import { exp03 } from "./exp03";
import { exp04 } from "./exp04";
import { exp05 } from "./exp05";
import type { Experiment } from "./types";

export type { Experiment, SubExperiment } from "./types";

export const experiments: Experiment[] = [exp01, exp02, exp03, exp04, exp05].sort(
  (a, b) => a.orderIndex - b.orderIndex,
);

export const totalSubExperiments = experiments.reduce(
  (total, experiment) => total + experiment.subExperiments.length,
  0,
);
