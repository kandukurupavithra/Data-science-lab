import type { Experiment } from "./types";

export const exp05: Experiment = {
  id: 5,
  expNumber: "EXP-05",
  title: "Data Visualization",
  category: "Data Preprocessing",
  sem: "Semester V",
  subject: "Data Science",
  coverPhoto:
    "https://images.pexels.com/photos/17483873/pexels-photo-17483873.png?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  overview:
    "Data Visualization using Python Matplotlib: generating Line Plots, Bar Plots, Stacked Bar Charts, Histograms, Scatter Plots, and Box Plots.",
  summary:
    "Rendered publication-grade statistical graphics representing distribution, correlation, and categorical comparisons.",
  code: `import matplotlib.pyplot as plt
import numpy as np

# Data
students = ["Pavitra", "Aarav", "David", "Lin"]
scores = [96, 92, 88, 94]

plt.figure(figsize=(6, 4))
bars = plt.bar(students, scores, color="#7E22CE", width=0.5)
plt.title("Data Science Lab Exam Scores", fontsize=12, fontweight="bold")
plt.xlabel("Student Name")
plt.ylabel("Score (%)")
plt.ylim(0, 105)

for bar in bars:
    yval = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2, yval + 1, f"{yval}%", ha="center", va="bottom", fontweight="bold")

print("Plot generated successfully!")`,
  pythonLibs: "matplotlib, pandas, numpy",
  videoUrl: "https://www.youtube.com/watch?v=aircAruvnKk",
  githubLink: "https://github.com/kandukurupavithra/Data-science-Experiments",
  output: "Plot generated successfully!",
  status: "Completed",
  orderIndex: 5,
  subExperiments: [
    {
      subExpNumber: "EXP-05.1",
      title: "Creating Line Plot",
      overview: "Plotting continuous functions and trend lines over time.",
      code: `import matplotlib.pyplot as plt
import numpy as np
x = np.arange(1, 6)
y = [85, 88, 91, 94, 96]
plt.plot(x, y, marker='o', color='#7E22CE', linewidth=2)
plt.title("Score Improvement Across Lab Practicals")
plt.xlabel("Practical Number")
plt.ylabel("Score")
print("Line plot created!")`,
      output: "Line plot created!",
      pythonLibs: "matplotlib, numpy",
    },
    {
      subExpNumber: "EXP-05.2",
      title: "create bar plot",
      overview: "Creating standard discrete categorical bar charts.",
      code: `import matplotlib.pyplot as plt
students = ["Pavitra", "Aarav", "David", "Lin"]
scores = [96, 92, 88, 94]
plt.bar(students, scores, color='#9333EA')
plt.title("Student Final Scores")
print("Bar plot created!")`,
      output: "Bar plot created!",
      pythonLibs: "matplotlib",
    },
    {
      subExpNumber: "EXP-05.3",
      title: "Stacked Bar plot",
      overview: "Creating stacked category comparative distributions.",
      code: `import matplotlib.pyplot as plt
students = ["Pavitra", "Aarav", "David"]
lab1 = [48, 46, 44]
lab2 = [48, 46, 44]
plt.bar(students, lab1, label='Lab Part 1', color='#7E22CE')
plt.bar(students, lab2, bottom=lab1, label='Lab Part 2', color='#C084FC')
plt.legend()
plt.title("Stacked Lab Evaluation Scores")
print("Stacked bar plot generated!")`,
      output: "Stacked bar plot generated!",
      pythonLibs: "matplotlib",
    },
    {
      subExpNumber: "EXP-05.4",
      title: "create Histogram",
      overview: "Visualizing frequency distribution of scores.",
      code: `import matplotlib.pyplot as plt
import numpy as np
np.random.seed(42)
scores = np.random.normal(90, 4, 100)
plt.hist(scores, bins=6, color='#7E22CE', edgecolor='white')
plt.title("Score Distribution Histogram")
print("Histogram generated!")`,
      output: "Histogram generated!",
      pythonLibs: "matplotlib, numpy",
    },
    {
      subExpNumber: "EXP-05.5",
      title: "create Scatter Plot",
      overview: "Analyzing correlation between two continuous numeric variables.",
      code: `import matplotlib.pyplot as plt
study_hours = [10, 8, 6, 9, 7]
scores = [96, 92, 88, 94, 90]
plt.scatter(study_hours, scores, color='#7E22CE', s=100)
plt.xlabel("Study Hours")
plt.ylabel("Exam Score")
plt.title("Study Hours vs Score Correlation")
print("Scatter plot created!")`,
      output: "Scatter plot created!",
      pythonLibs: "matplotlib",
    },
    {
      subExpNumber: "EXP-05.6",
      title: "Create Box Plot",
      overview:
        "Examining quartile spreads, median, and variance with a box and whisker plot.",
      code: `import matplotlib.pyplot as plt
scores = [88, 90, 92, 94, 96, 92, 94, 95]
plt.boxplot(scores, patch_artist=True, boxprops=dict(facecolor='#C084FC', color='#7E22CE'))
plt.title("Score Distribution Box Plot")
print("Box plot created!")`,
      output: "Box plot created!",
      pythonLibs: "matplotlib",
    },
  ],
};
