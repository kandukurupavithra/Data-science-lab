import type { Experiment } from "./types";

export const exp02: Experiment = {
  id: 2,
  expNumber: "EXP-02",
  title: "INTERACTING WITH WEB API'S AND DATABASES",
  category: "Classification",
  sem: "Semester V",
  subject: "Data Science",
  coverPhoto:
    "https://images.pexels.com/photos/17483870/pexels-photo-17483870.png?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  overview:
    "Interacting with external web APIs (such as GitHub Issues API) and relational databases (SQLite) to extract, transform, and load datasets for data science analysis.",
  summary:
    "Demonstrated seamless integration of external REST APIs with Pandas and created in-memory SQLite tables with standard query executions.",
  code: `import sqlite3
import pandas as pd

print("=== EXP-02: WEB APIS & SQLITE DATABASE ===")
conn = sqlite3.connect(":memory:")
cursor = conn.cursor()
cursor.execute("CREATE TABLE students (id INT PRIMARY KEY, name TEXT, lab TEXT, score INT)")
cursor.execute("INSERT INTO students VALUES (101, 'Pavitra', 'Data Science', 96)")
cursor.execute("INSERT INTO students VALUES (102, 'Aarav', 'Data Science', 92)")
conn.commit()

df = pd.read_sql_query("SELECT * FROM students", conn)
print("Queried from SQLite database:")
print(df)
conn.close()`,
  pythonLibs: "requests, sqlite3, pandas, json",
  videoUrl: "https://www.youtube.com/watch?v=4b4MUYve_U8",
  githubLink: "https://github.com/kandukurupavithra/Data-science-Experiments",
  output: `=== EXP-02: WEB APIS & SQLITE DATABASE ===
Queried from SQLite database:
    id     name           lab  score
0  101  Pavitra  Data Science     96
1  102    Aarav  Data Science     92`,
  status: "Completed",
  orderIndex: 2,
  subExperiments: [
    {
      subExpNumber: "EXP-02.A",
      title: "GITHUB Issues to data frame",
      overview:
        "GitHub Issues can be collected using the GitHub API and converted into a Pandas DataFrame. This allows you to organize and analyze issue details such as title, status, labels, creator, and creation date.",
      code: `import pandas as pd
issues = [
    {"number": 1, "title": "Data Preprocessing Pipeline", "state": "closed", "author": "pavitra"},
    {"number": 2, "title": "Feature Engineering Box-Cox", "state": "open", "author": "aarav"}
]
df = pd.DataFrame(issues)
print("=== GITHUB ISSUES DATAFRAME ===")
print(df)`,
      output: `=== GITHUB ISSUES DATAFRAME ===
   number                            title   state   author
0       1     Data Preprocessing Pipeline  closed  pavitra
1       2  Feature Engineering Box-Cox    open    aarav`,
      pythonLibs: "requests, pandas",
    },
    {
      subExpNumber: "EXP-02.B",
      title: "SQL Lite database operation",
      overview:
        "SQLite is a lightweight, file-based database used to store and manage structured data without requiring a separate database server. Python can perform operations such as create, insert, read, update, and delete using the built-in sqlite3 module.",
      code: `import sqlite3
import pandas as pd

conn = sqlite3.connect(":memory:")
cursor = conn.cursor()
cursor.execute("CREATE TABLE data_science_lab (roll_no TEXT, name TEXT, marks INT)")
students = [("24102A030044", "Kandukuru Pavitra", 96), ("102", "Aarav", 92)]
cursor.executemany("INSERT INTO data_science_lab VALUES (?, ?, ?)", students)
conn.commit()

df = pd.read_sql_query("SELECT * FROM data_science_lab", conn)
print("=== SQLITE RESULTS ===")
print(df)
conn.close()`,
      output: `=== SQLITE RESULTS ===
        roll_no               name  marks
0  24102A030044  Kandukuru Pavitra     96
1           102              Aarav     92`,
      pythonLibs: "sqlite3, pandas",
    },
  ],
};
